# Chennai Afternoon Drive

The deliverable is a static browser game. No server, login, paid API or streamed map is needed. A thin Vinext/React page embeds the self-contained game; Vercel serves its static export.

| Module | Responsibility |
| --- | --- |
| `public/game/main.js` | Fixed-step simulation, input, cameras, HUD, settings, game state, recovery |
| `roads.js` | Hand-authored road-provider data, place labels, nearest-road query |
| `world.js` | Road ribbons, identical collision meshes, buildings, scenery, vehicle visuals |
| `vehicle.js` | cannon-es rigid body and four raycast suspension wheels; exposed tuning |
| `canvas-renderer.js` | Software 3D fallback with triangle depth buffer and spatial cells |
| `audio.js` | Original Web Audio engine and signal synthesis |
| `index.html`, `style.css` | Menus, HUD, minimap, controls and responsive layout |

Physics runs at 60 Hz with a bounded accumulator. Rendering is separate: Medium/Low target 30 rendered frames per second, High/Epic 60, software fallback 24. Long browser stalls discard excess simulation time instead of launching the vehicle through the world. Losing focus pauses and clears held inputs.

Road visuals and collision use the same sampled curve coordinates, with road collision at Y=0.045 m. A support plane at Y=-0.08 m also covers verges. Static buildings, all generated tree trunks, signal posts and selected curb bodies block the SUV. Only obstacles within roughly 170 m plus their radius are activated; the set refreshes every 0.5 simulation seconds. Road collision stays loaded throughout the region. All collision loads before Play is enabled. No network-dependent collision or origin shifting is needed for this bounded local coordinate system.

Most visual geometry uses instancing; the world is generated once with a deterministic seed. Local signs use tiny canvas textures. CPU fallback uses 100 m spatial cells and a real software depth buffer; its visual quality and performance differ from WebGL. Cameras share the same transforms in both renderers.

`roads.js` wraps generated OSM data with geographic projection, raw-vertex resampling, clearance checks and bounded extents. `scripts/import-osm.py` maintains an auditable source-to-game transform. `map-boundary.js` builds continuous perimeter colliders and visible rails. Complex grade-separated routes are excluded; selected bridge geometry is flattened without a lower gameplay road. See MAP_DATA.md.

No monolithic engine level, backend secret, cloud physics service or mutable map cache exists. Settings are optional browser-local preferences. Unsupported WebMCP safely falls back to normal UI; the optional recovery tool invokes the same recovery action.

## Revision modules

- `transmission.js`: deterministic six-speed automatic, RPM and per-wheel torque estimate; consumed by the existing fixed-step vehicle physics.
- `audio.js`: load/RPM-based original Web Audio engine voice, intake/turbo/tire layers.
- `touch-input.js`: per-pointer action ownership, capture, independent multi-touch, release/cancel/focus cleanup.
- `minimap.js`: aspect-correct uniform projection from actual road vertices, canvas size matched to its CSS rectangle and device pixel ratio.
- `stores.js`: curated factual business-name/address/source registry with explicitly illustrative anchors. `world.js` builds roadside facades and a Phoenix tenant directory.
- `public/qa/mobile.html`: internal responsive test harness. It is not included in the optimized Vercel game package. `?qa=1` exposes visible driving and pedal diagnostics for testing.

## Turbo, traffic and soundscape

- `traffic.js` allocates 42 vehicles once (35 cars, 7 buses), samples left-side lanes from the same road curves, and updates at 60 Hz before player physics. Nearby dynamic collision bodies activate within 190 m; visuals within 320 m. Following-distance braking, signal compliance and pedestrian yielding are simplified. Vehicles wait at visible route ends and reverse only when distant; reset clears nearby traffic. Shared geometry/materials keep memory small. No external traffic API is used.
- `instruments.js` builds SVG speed/RPM dials once and updates needle transforms from physical speed and gearbox RPM. Small readouts remain for exact values. There are no raster dashboard assets.
- `soundscape.js` supplies original procedural music and city sound on separate gain buses. Scheduling uses bounded look-ahead and finite voices with cleanup, without interval timers or music downloads. Focus loss pauses simulation and fades audio. Engine muting does not silence music or city sounds.
- The portrait camera view offset is shared by WebGL and the software projection. Landscape restores the full normal projection.
- `tests/turbo-traffic.mjs` verifies normal speed and the eight-second boost limit using actual physics, boost release, traffic following, collider alignment, recovery, pool bounds and analogue mapping.

## Night city systems

- `boost.js`: eight-second reserve, half a second of recharge per inactive simulation second, release-to-rearm latch after exhaustion. Recovery preserves charge; settling advances physics without recharge.
- `route-utils.js`: shared distance-based lane sampling for cars, signals and walkers.
- `signals.js`: five simulated crossings on OSM roads, road-grounded stop lines and visible red/amber/green heads. Conflicting approaches get separate green phases, followed by a shared pedestrian phase. Walk entry is limited to its first two seconds to leave crossing clearance.
- `pedestrians.js`: bounded pool of 56 original figures. Ten crossing walkers and 46 pavement walkers use shared geometry and materials; figures cull beyond 170 m. Crossing walkers yield before entering near the player. Traffic considers them as obstacles. No pedestrian rigid bodies or injury simulation.
- `street-props.js`: standing lamps begin static; a swept SUV footprint activates breakaway on impact, reduces speed once and releases a 95 kg dynamic post. Visuals follow the physical body until it settles. Nearby activation and sleeping-body removal bound physics cost. Recovery searches nearby road offsets outside fallen debris.
- `night-mode.js`: saved day/night appearance, emissive facade trim/windows, a quality-controlled pool of 6–16 shadowless street lights and a vehicle spotlight. The software renderer uses lightweight local color fields. Night mode automatically enables headlights; L still controls them.

Fixed-step order: signals, pedestrians, traffic, breakaway detection, vehicle physics. Rendering synchronizes physical lamp poses and updates nearby night lighting. Optional visible QA controls stage real tree and lamp impacts and a crossing inspection without production UI clutter.

## Physical crashes and ambient sky

Traffic bodies now have finite mass (1,250 kg cars, 8,500 kg buses), horizontal translation and yaw freedom. Normal AI follows the route; a significant contact switches that NPC to free impact motion. It is not snapped back while nearby. `crash-feedback.js` projects temporary angry emojis above impacted NPCs and adds a small, damped camera reaction and sound. `vehicle.js` uses dedicated chassis/solid and chassis/traffic contact materials; trees retain low restitution.

`geometry.js` supplies cached bevelled boxes and a sloped cabin mesh. Building windows gain sills, frames and balconies; tree and character silhouettes use additional segments. Shared meshes/materials keep the payload small. Collision stays simpler than visible geometry.

`sky.js` separates a bounded randomized event schedule from visuals. Only one event per type is active, with fixed expiration. Sun/moon/stars anchor to the viewer without road collision. Expired event meshes/materials are disposed. A scene revision counter refreshes software-renderer dynamic registration when event objects enter or leave, preventing stale references and missing effects. Sky rendering does not write road depth, and software sky pixels stay above the horizon.

Ten-metre streetlight placement samples route distance instead of every eighteenth road point. Intersection mouths and duplicate placements are excluded. Physical lamp bodies activate within 75 m; visuals cull at 180 m. Nearby night light count depends on graphics quality, rather than allocating a light for every lamp.

Mobile media rules hide the larger desktop digital display and replace them with speed/gear, a compact reserve and an upper-right minimap. World simulation, controls and camera transforms remain shared.

## September 14 map and interface revision

Road vertices preserve OSM bends/junctions instead of Catmull-Rom smoothing. One-way traffic uses the centre of its mapped carriageway and does not reverse into opposing flow at route ends. Signal placement checks clearance from every road and moves the stop line with its head. All 58 interior route pieces have mesh-contact verification. The perimeter is segmented into 438 overlapping static bodies, activated by the existing collision-area manager; an out-of-bounds recovery check is retained as a final fallback. Window/shop lights share the same bounded real-light pool as streetlights. The single Sound menu pauses input safely and resumes when dismissed. Analogue instruments are no longer mounted in the game; existing gauge mapping tests remain historical utilities.
