# Vercel production deployment

## OSM neighbourhood revision — 2026-09-14

The game is built and tested locally, but this revision is **not deployed**.

The production upload was rejected with HTTP 403: the connected Vercel account is not authorized for the `sam-2717` scope (`team_YXd7f3fHNem9UjxrnQ9eyv7H`). No new deployment ID was returned. No access settings were changed and no alternate project was created.

- Existing production alias: https://chennai-afternoon-drive-sam-2717.vercel.app
- Final artifact: 18 static files, 1,080,027 bytes (1.08 MB uncompressed)
- Build: locally compiled static Three.js/cannon-es game; no server runtime
- Previous accepted upload: `dpl_789mDh4GrrqXAHoyU3YcMViuVhcs` (September 13)

Reconnect Vercel with access to the sam-2717 workspace, then deploy `web-build/` from the supplied ZIP to the existing project. Alternatively run `node scripts/package-vercel.mjs` from the source checkout and deploy the resulting `deploy/` directory with an authorized account. There are no runtime API keys or map accounts to configure.

The failed upload preceded a final road-paint correction; the supplied bundle includes that correction. The source and bundle contain no Vercel credentials.
