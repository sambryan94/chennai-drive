# Map data — 14 September 2026

The road network now uses a bounded **OpenStreetMap export**, replacing the old invented schematic. Longitude/latitude vertices and shared junctions are retained. Selection contains 164 OSM ways, merged into 99 gameplay polylines, with about 33.12 km of centreline geometry (includes separately mapped carriageways). All ways are connected through source vertices.

There are **24 distinct named interior streets** after normalizing the duplicated 10 Street/10th Street spelling. They sit inside the OSM block enclosed by Velachery Main Road, Velachery Bypass Road/100 Feet Road and the Vijayanagar junction links. Examples include Rajalakshmi Nagar 1st, 2nd and 3rd Main Roads; 5th and 6th Cross Streets; 7th Cross Street; Jagannathapuram 1st, 2nd and 3rd Main Roads; Janakpuri 2nd Street; Lakshmipuram Main Road; Brahmin Street and Nattar Street. Original OSM spellings are preserved in the downloadable data.

Main routes include Velachery Main Road, the bypass, 100 Feet Road, a bounded Inner Ring Road Southern Sector section, Anna Salai, Guindy Bridge approaches and Taramani Link Road. Kathipara is an approach, not a reconstruction of the interchange. Connections outside the chosen bounds are deliberately closed by the visible perimeter. No invented connector is used to join disconnected roads.

## Sources and reproducibility

`public/game/data/roads.geojson` is the clipped source geometry with OSM way IDs/tags. Its metadata records the export timestamp, selection polygon, projection and limits. `roads-data.js` is the generated compact runtime provider. `places.geojson` preserves the OSM locations used for mapped shops, Phoenix, Rajalakshmi Nagar and Guindy. The in-game Credits links to the downloadable road data.

The one-off export came from `https://overpass.kumi.systems/api/interpreter` after the primary public instance timed out. No raster tile servers were used. No API key or live map service is needed during gameplay.

Initial bounded Overpass query:

```overpass
[out:json][timeout:25];
(way[highway~"^(primary|secondary|tertiary|residential|unclassified|living_street|trunk|primary_link|secondary_link|trunk_link)$"](12.965,80.195,13.015,80.23);
 nwr[name~"Phoenix|Kathipara|Dhandeeswar|Vijayanagar",i](12.965,80.195,13.015,80.23););
out body geom;
```

To refresh: obtain this modest vector export using reasonable public-instance limits, then run `python scripts/import-osm.py export.json` with Python 3 and Shapely 2.x. The importer clips to longitude 80.2038–80.225 / latitude 12.9676–13.014, selects the enclosed neighbourhood, removes disconnected ways and joins matching consecutive ways. Review any changed names/topology before publishing. Run the map/physics checks and inspect the playable route after every refresh.

Projection: local equirectangular metres around 12.990000 N, 80.219500 E; X east, Z south. OSM coordinates round-trip within 0.001 m of the packaged vertices; this is numerical preservation, **not a claim that OSM has millimetre real-world accuracy**. No geospatial spline smoothing moves junctions. Straight segments are subdivided at at most nine metres.

## Limits and gameplay corrections

- Heights are flat gameplay approximations. No surveyed road elevation, complex multi-level Kathipara or Velachery flyover simulation is included. The selected Guindy bridge geometry crosses an unrendered railway, not a lower gameplay road.
- Road widths are gameplay estimates (normally seven metres for a mapped one-way carriageway or residential street, fourteen for a two-way main road; bounded numeric widths are used when available).
- Buildings, trees, streetlights and traffic signals are procedural scenery, not surveyed inventory. Signals use five simulated junction locations, with all 16 heads and colliders checked against every nearby carriageway. Their stop lines and AI controls share the same positions.
- Streetlights use 50 m stations, skipping junction conflicts and posts too close to another carriageway's posts. Shopfronts/occupied windows supply additional local night light.
- Shop geocodes use available OSM records. Simplified facades may be set back a few metres to keep the road clear; see STOREFRONTS.md. Unverified older standalone shop placements were removed instead of presented as accurate.
- The concrete perimeter is a **game boundary**, visible on the minimap; it does not represent real Chennai walls. Road width, current access, names and real-world conditions may differ. Do not use this game for navigation.

## Licensing

Road and location data: © OpenStreetMap contributors, **Open Database License 1.0**. Modified map datasets remain available under ODbL in the game download and source. Keep the visible attribution and licence links unobstructed. ODbL applies to these datasets; original game code/art and MIT third-party code retain their respective licences.

- https://www.openstreetmap.org/copyright
- https://opendatacommons.org/licenses/odbl/1-0/
- https://wiki.openstreetmap.org/wiki/Overpass_API

Three.js 0.185.0 and cannon-es 0.20.0 are MIT; their notices ship with the build. No Google imagery, extracted car model, Volkswagen logo or commercial music is included.
