# Chennai · Afternoon Drive

A small, playable browser driving prototype built for the revised low-fidelity brief. Explore a connected OSM road network around Velachery, Phoenix Marketcity and Guindy, including 24 named interior streets in a cherry-red compact SUV.

**The map is approximate and the vehicle is an original placeholder, not an exact Volkswagen Taigun.** No commercial model, badge, Google imagery or surveyed map is included. See MAP_DATA.md and VEHICLE_TUNING.md.

## Play

Open the deployed URL in current Chrome or Edge. Click **Start your drive**. Medium is the recommended preset for the HP Envy x360 Ryzen 5 4500U with 8 GB RAM. Keep browser hardware acceleration enabled. Low reduces graphics cost further. WebGL is preferred; a simpler software 3D renderer is available automatically if WebGL is unavailable.

No installation, account or map API key is required. OSM road data ships with the game; scenery is generated locally. Game files are far below 1 GB; the editor toolchain is separate from the player download. Actual laptop frame rate is not yet measured.

| Input | Action |
| --- | --- |
| W / Up | Accelerate |
| S / Down | Brake, then reverse after stopping |
| A D / Left Right | Steer |
| Space | Handbrake |
| Shift + accelerator | Turbo boost (up to 180 km/h) |
| C | Chase / bonnet camera |
| R | Recover to nearest safe road |
| L | Headlights |
| N | Day / neon night |
| Q / E | Left / right indicator |
| H | Horn (Engine channel) |
| Esc | Pause / resume |
| Backtick | Performance and local-coordinate overlay |
| Mouse drag | Limited chase-camera orbit |

Controller: RT accelerator, LT brake/reverse, left stick steering, A/Cross handbrake, B/Circle + RT turbo, Y/Triangle camera, Back/Select recovery, Start pause. Touch buttons appear on coarse-pointer devices. Steering sensitivity and controller dead zone are editable. Engine, music and city ambience default to on and start with the Play gesture. A single Sound button opens grouped engine, music, city ambience, master mute and volume controls; preferences persist. Mobile TURBO includes the accelerator, so hold it instead of GO. Normal driving is limited to 120 km/h; boost raises the limit to 180 km/h. Releasing boost gradually returns the car to the normal limit. The reserve lasts eight seconds and refills from empty in 16 seconds while inactive. After emptying it, release TURBO to rearm once at least one second has recharged. The bar shows the remaining seconds. Day/night selection persists between visits.

## Source and local setup

Runtime versions: Three.js 0.185.0; cannon-es 0.20.0. Build wrapper: React 19.2.6, Vinext 1.0.0-beta.5, Vite 8.0.13; Node 22.13+; pnpm 11.25.0. The lockfile pins dependencies. Generated game geometry and synthesized audio do not require Blender or Unreal.

The easiest development preview needs only Python 3:

```sh
python -m http.server 8080 --directory public
```

Open http://localhost:8080/game/index.html. Do not double-click index.html: browser modules require HTTP.

For the framework wrapper and reproducible optimized Vercel package:

```sh
pnpm install --frozen-lockfile
pnpm build
node scripts/package-vercel.mjs
```

`deploy/` contains the complete static hosted game. Its index.html can be served from any normal static host. No serverless functions or environment variables are needed.

## Vercel

The supplied vercel.json selects static hosting. Deploy the contents of deploy/ using Vercel's authenticated deployment flow. For CLI deployment, sign in using your own account, then run from deploy/:

```sh
vercel link
vercel --prod
```

Never paste a token into game code or commit authentication files. `.env.example` intentionally contains no required secrets.

## Verification

```sh
node tests/physics.mjs
node tests/revisions.mjs
node tests/turbo-traffic.mjs
node tests/night-city.mjs
node tests/sky-crashes.mjs
```

Open the game with `?qa=1` and use **Run driving checks** to exercise the visible accelerated physics test sequence. See TEST_REPORT.md for observed results and limits.

## Attribution and licensing

The game visibly identifies the map as an original approximation. Third-party MIT notices ship with the game. Keep these notices in redistributed builds. Geometry and audio are original. Volkswagen names in documentation identify the desired future asset, not endorsement or licensed vehicle branding.

## Known limitations and next steps

- Simplified flat roads and intersections; no accurate Kathipara flyover. Traffic follows lanes and signals, with simplified queues and pedestrian yielding.
- No cockpit, damage, missions or multiplayer.
- Game-quality approximate physics, not a validated vehicle engineering simulation.
- Night includes headlights, neon shop trim and a fixed pool of nearby street lights. The software renderer approximates illumination.
- CPU fallback has reduced detail and performance; GPU rendering and physical-controller behavior need testing on the user's laptop.
- No internet is needed for the map once the page has loaded, but offline reload is not installed as a PWA.

Backlog: laptop-specific profiling; licensed Taigun mesh; surveyed elevation and facade alignment; grade-separated flyovers; richer vehicle models and traffic junction behavior; expansion toward Adyar and Taramani.

## September 12: rechargeable boost and night city update

The revised six-speed automatic reaches D6 and the 120 km/h normal limit. Shift/phone TURBO/gamepad B adds an arcade boost toward 180 km/h. Simple speed / gear and RPM readouts show the simulation state, with a thin RPM bar.

A fixed pool of 35 cars and 7 buses keeps left, follows nearby vehicles and stops at five signalized crossings. Fifty-six pedestrians walk along pavements or cross during a separate walk phase; traffic yields to crossing walkers. Pedestrians are decorative and have no player collision or injury simulation. Junction logic remains simplified.

Switch between warm daylight and an original neon night palette using the top-bar button or N. Magenta/cyan storefronts, pools of street light and vehicle headlights evoke a late-night city. No commercial song or music-video artwork is included. Existing original calm music remains independently switchable.

All 295 generated trees have solid trunks. Street lamps break away, topple as rigid bodies and slow the SUV on impact; fallen lamps remain down for the session. Recover avoids nearby fallen lamp debris. Traffic-signal supports remain fixed.

Original calm generative music, filtered city/shop ambience and traffic sounds add atmosphere without audio downloads. Engine, Music and City switches work independently; pause/focus loss fades all channels. The engine remains a synthesized small three-cylinder turbo-petrol impression, not a Volkswagen recording.

Mobile pedals retain independent pointer capture and suppress text selection. Four street businesses now use OSM positions, plus six verified Phoenix directory entries; see STOREFRONTS.md. The compiled game is **1,080,027 bytes in 18 files (1.08 MB)**, including downloadable ODbL map data. All 81 automated checks pass. See TEST_REPORT.md for evidence and hardware limits.

## Crash, sky and detail update

Buildings now produce a damped physical rebound, and traffic vehicles exchange momentum on impact. Crashed NPCs stop following their route, show a five-second angry emoji, and remain displaced until distant enough to recover out of view. Trees retain their firm stopping collision. This is simplified rigid-body crash response, with no deformable bodywork.

Day includes a visible sun and random flights/rainbows. Night adds the moon, stars, flights, meteor showers and passing asteroid effects. Events are cosmetic, pause with gameplay and clean themselves up; they never strike the road. Rainbows occur only by day; meteors and asteroids only at night.

Streetlights use 50-metre stations: 419 posts after intersection and adjacent-carriageway exclusions. The earlier subdued ambient night lighting is restored. Warm shopfronts and occupied building windows add light, with facade spill sharing the bounded 6/10/14/16 point-light pool. A continuous solid map perimeter contains the player and NPCs.

The SUV has bevelled bodywork, sloping cabin glass and 32-segment tires; traffic, pedestrians, trees and building facades have additional geometry. The player vehicle contains 3,462 triangles. Medium supports a 1366 × 768 rendering budget; High 1920 × 1080 and Epic 2560 × 1440. The result is a sharper stylized game, not a photorealistic asset pack. Actual resolution is capped by viewport and device pixel ratio. The automatic software fallback remains lower resolution.

Phones use compact speed/gear readouts at the upper left and a small map at the upper right, leaving the car visible. The turbo reserve remains visible below the speed readout. Desktop uses the restored simple speed/gear and RPM display.

### Requested music

No version of The Weeknd's “Blinding Lights” has been bundled. A lite edit, instrumental or cover does not automatically clear the underlying composition. Public game use requires appropriate composition/synchronization permission and, for an existing recording, recording permission. A supplied license must cover the particular version, game distribution and hosting. Until then the existing original procedural music remains. Sources: [US Copyright Office, separate composition and recording rights](https://www.copyright.gov/circs/circ56a.pdf) and [music licensing for video games](https://www.iconcollective.edu/license-music-for-video-games).
