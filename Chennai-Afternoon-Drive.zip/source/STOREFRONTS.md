# Storefront locations — 14 September 2026

Four standalone stores now use OSM coordinates. Six verified Phoenix tenants remain on the mall directory. Original schematic street placements without a reliable location have been removed. Names provide orientation and imply no affiliation. Buildings are original stylized geometry; footprint dimensions and collision-safe setbacks are approximate. OSM entries may be outdated.

| Name | Placement | Source |
|---|---|---|
| POORVIKA | 12.9720985, 80.2191648 | [OSM location](https://www.openstreetmap.org/way/929083568) |
| BATA | 12.9744602, 80.2206389 | [OSM location](https://www.openstreetmap.org/node/13638977920) |
| THE CHENNAI SILKS | 12.9699385, 80.219036 | [OSM location](https://www.openstreetmap.org/node/8697656183) |
| RELIANCE DIGITAL | 12.9716089, 80.2195973 | [OSM location](https://www.openstreetmap.org/node/8616601057) |
| CROMA | Phoenix directory | [Retailer/mall listing](https://store.croma.com/location/tamil-nadu/chennai/velachery) |
| RELIANCE DIGITAL | Phoenix directory | [Retailer/mall listing](https://www.reliancedigitalstores.in/?search=Velachery+Main+Road%2C+Chennai%2C+600042) |
| BATA | Phoenix directory | [Retailer/mall listing](https://stores.bata.com/bata-shoes-sandals-store-in-velachery-main-road-velachery-chennai) |
| LENSKART | Phoenix directory | [Retailer/mall listing](https://www.lenskart.com/stores/optometrist-sunglasses-velachery-road-chennai-60895/home) |
| TANISHQ | Phoenix directory | [Retailer/mall listing](https://stores.tanishq.co.in/store-locator/jewellery-stores/TamilNadu/Chennai/Velachery-VEL) |
| SATHYA | Phoenix directory | [Retailer/mall listing](https://www.phoenixmarketcity.com/chennai/brand/Sathya/2743) |

The clipped location dataset is public/game/data/places.geojson, © OpenStreetMap contributors, ODbL 1.0. To add a street branch, obtain a defensible geocode and check the complete road union before placing its facade. See MAP_DATA.md for licensing and update steps.
