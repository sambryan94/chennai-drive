# Verification — 14 September 2026

## Automated checks

**81 checks passed** across six suites, using the actual cannon-es physics and generated world. Raw results are in evidence/*-results.json.

| Suite | Checks | Main coverage |
|---|---:|---|
| physics.mjs | 9 | Acceleration, braking, reverse, steering, handbrake, speed limit, sampled full-network wheel contacts, wall collision |
| revisions.mjs | 15 | Transmission, audible RPM changes, touch ownership, minimap scale and store provenance |
| turbo-traffic.mjs | 14 | Eight-second boost, traffic following, recovery and bounded pools |
| night-city.mjs | 17 | Trees, falling posts, signal phases, stop/resume and pedestrians |
| sky-crashes.mjs | 14 | Collision rebound, NPC momentum/anger, sky schedule, cleanup and geometry |
| map-neighbourhoods.mjs | 12 | Geographic preservation, connectivity, interior collision, boundary impacts, signal/lamp placement and facade lights |

The map suite confirms all 164 selected OSM ways belong to a connected graph; 24 normalized named interior streets; all 58 interior route pieces settle onto real road-mesh collision; all 16 signal heads sit clear of every carriageway; and all 419 lamps use 50 m stations. A 50 m/s (180 km/h) impact against each of the four perimeter edges remains inside the map. All physical checks run with the game scene, not a visual-only mockup.

The export-to-game vertex error is below 0.001 m. This tests conversion arithmetic, not the accuracy of OSM against the physical city. Vehicle wheels were sampled around the network; this is not an exhaustive test of every possible trajectory through a populated junction.

## Browser verification

The compiled road scene passed acceleration, brake/reverse, steering, handbrake, both cameras and recovery checks. Typical observed cloud software-renderer speed was 12–21 FPS at 724 × 497, dependent on camera and nearby geometry. This cloud environment has no usable WebGL GPU; these figures do not predict the HP laptop's hardware-accelerated frame rate.

The grouped Sound menu was opened during driving, which safely paused input. Master mute cleared all three channel controls; enabling it restored the channels, and closing the menu resumed the drive. Individual music selection also worked. Preferences persist locally.

390 × 780 phone portrait visibly retains a clear central car view, compact upper-left speed/gear and boost, upper-right map, pedals and four toolbar buttons. 844 × 390 landscape shows the compact instruments and hides the larger desktop display. These checks use responsive browser frames rather than a physical phone.

The final bundle was rebuilt after a visual-only paint correction; an interior junction was rechecked with 4/4 road contacts and no crossed edge markings. The earlier full driving sequence is saved in evidence/osm-browser-checks.txt.

Night mode visibly includes warm lit windows and wider-spaced streetlights. Desktop instruments show speed/gear, numerical RPM and a thin RPM bar. The map and its perimeter share the geographic projection.

## Distribution and limitations

The final static game contains **18 files / 1,080,027 bytes (1.08 MB)**, including downloadable ODbL road/location data. The optional source ZIP and screenshots are separate. The framework build succeeded; Vercel rollout details are recorded in DEPLOYMENT.md.

Unverified: physical HP Envy performance, real touchscreen/controller hardware and long-duration sessions. No photorealistic Chennai buildings, surveyed elevations, navigation accuracy or complete multi-level flyovers are claimed. Signals are simulated, not a surveyed traffic-light inventory. NPCs remain simplified, with no full route-planning or deformation model. All music remains original synthesis.

No exact coding-agent token meter is available in this environment; a measured token total cannot be reported reliably.
