# Vehicle tuning and approximations

This is an original cherry-red compact-SUV placeholder, not a licensed or exact Volkswagen Taigun. All values are gameplay approximations, not asserted production specifications. Turbo is an arcade gameplay boost.

| Parameter | Value |
| --- | --- |
| Mass | 1,320 kg |
| Wheelbase / track | 2.55 m / 1.52 m |
| Wheel radius / width | 0.335 m / 0.215 m |
| Visual size | about 4.2 × 1.8 × 1.6 m |
| Suspension rest length / travel | 0.34 m / ±0.19 m |
| Suspension stiffness | 32 cannon units |
| Compression / relaxation damping | 4.4 / 4.8 |
| Tire frictionSlip | 3.4 asphalt; 2.0 verge |
| Drive | Front two wheels |
| Normal force cap per front wheel | 2,250 N, further limited by gearbox torque |
| Boost multiplier | 3.0 × available wheel force |
| Brake / rear handbrake impulse | 42 / 68 solver units |
| Low-speed steering maximum | 0.48 rad |
| Speed limits | 120 km/h normal; 180 km/h boost; about 20 km/h reverse |
| Linear damping | 0.003 |
| Road load | 95 + 0.40 × speed² N, speed in m/s |
| Forward ratios | 3.60, 2.25, 1.55, 1.18, 0.93, 0.76 |
| Final drive | 3.65 |
| Idle / RPM limit | 820 / 6,000 RPM |
| Gear-change interruption / cooldown | 0.28 / 1.20 seconds |

`vehicle.js` exports TUNING; `transmission.js` contains the torque curve and gearing. The previous heavy velocity damping and early wheel-force taper prevented the car exceeding roughly 66 km/h. Explicit road resistance, revised shift thresholds and a narrow speed limiter now permit all six gears and 120 km/h in the actual rigid-body simulation. Tests measured 119.845 km/h normal and 179.900 km/h after an eight-second boost from normal cruising speed; the display rounds to 120/180.

Normal full-demand upshifts occur near 2,800 RPM; boost holds a gear toward 3,850 RPM. Light-demand shifts occur earlier. Separate downshift thresholds and a cooldown prevent hunting. Wheel speed, gear ratio and converter slip determine RPM; a shift interrupts torque and drops audible pitch. The approximate torque plateau is 178 Nm, following the previously sourced [Volkswagen India launch specification](https://www.volkswagen.co.in/en/discover-volkswagen/news/archives/volkswagen-india-launches-suvw-taigun-price.html). Exact factory ratios were not obtained.

The chassis collision box lies below the visible cabin for a low centre of mass. Raycast wheel springs provide suspension forces. Anti-roll torque and angular damping aid recovery. Steering reduces with speed, including an approximately 8 m/s² lateral-demand cap. This is a simplified steering rule, not independent ABS, stability control or measured tire dynamics. There is no physical clutch or detailed engine-inertia model.

Brake first slows the car, then engages reverse after a 0.32-second hold near a stop. Boost requires forward throttle on the road and is suppressed by brake, handbrake and off-road travel. Releasing boost applies gradual over-limit braking, rather than snapping velocity to 120. The eight-second reserve refills at 0.5 seconds per inactive simulation second (16 seconds from empty). Exhaustion locks boost until the button is released and at least one second has recharged. Reset cannot refill the reserve; pause freezes simulation and recharge.

Wild Cherry Red is approximated, not a calibrated paint sample. No cockpit/interior or Volkswagen badges are supplied. Chase and bonnet cameras, steering, wheel spin, suspension and visual lamps work. Night headlights project a beam in WebGL; the software renderer approximates the illuminated area. Portrait framing shifts the camera projection to improve visibility above the controls.

## Audio

`audio.js` synthesizes combustion pulses at RPM/40, crank harmonics, intake/turbo whistle and tire noise. Load, shifts and camera position affect tone. This is an original small turbo-petrol impression, not an authentic Taigun recording. No samples were copied from videos, games or configurators.

`soundscape.js` generates a quiet 68 BPM chord/bell piece with a short original reverb. City ambience combines filtered street noise, abstract market chatter, nearby traffic engine hum, distant horns and shop bells. It is stylized and contains no intelligible dialogue or recorded Chennai soundscape. Finite musical/event voices are capped at 32 and disconnected after playback. The grouped Sound menu controls all buses with master mute, volume and individual Engine, Music and City switches and persist between visits. They default on and begin after Play to comply with browser audio activation.

## Roadside impacts

Tree trunks use fixed box collision; their visual crowns do not add expensive foliage collision. A lamp footprint sweep prevents a fast car from skipping the narrow post between physics steps. At impact the post becomes a 95 kg rigid body, receives a controlled tipping impulse, and the car retains 72% of its velocity before the contact solver handles subsequent contact. This deliberately simplified breakaway is a game effect, not a calibrated structural model. Signal posts remain hard obstacles. Fallen lamp debris persists for the session and recovery avoids its vicinity.

## Updated vehicle contacts

Building/chassis restitution is 0.24 with friction 0.32. Vehicle/vehicle restitution is 0.22 with friction 0.28. NPC cars use a 1,250 kg body and buses 8,500 kg. NPC motion is constrained vertically, with yaw and horizontal momentum free during impacts. These are gameplay approximations; there are no NPC suspension wheels or crumple zones. A normal-impact speed above 2.2 m/s triggers the five-second angry-driver reaction. Nearby crashed NPCs remain physical; distant ones return to their route outside the player's immediate view. Trees use the prior low-restitution contact to continue stopping the SUV.

A 15 m/s building-impact test measured up to 4.95 m/s rebound. An angled test retained 3.19 m/s lateral motion and 2.20 m/s away from the wall. A rear impact transferred up to 9.24 m/s to the tested NPC. These are controlled test outcomes, not measured Taigun crash data.
