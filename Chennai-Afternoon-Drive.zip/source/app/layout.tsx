import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Chennai · Afternoon Drive",
  description: "A lightweight 3D driving game through a Chennai-inspired Velachery–Guindy route.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
