export default function Home() {
 return <iframe title="Chennai Afternoon Drive" src="/game/index.html" allow="gamepad; fullscreen" style={{position:'fixed',inset:0,width:'100%',height:'100%',border:0}} />;
}
