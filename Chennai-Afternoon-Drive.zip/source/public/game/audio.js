import {createSoundscape} from './soundscape.js';
// Original synthesis inspired by a small three-cylinder turbo petrol engine.
// No Volkswagen recording, extracted samples or claim of an exact acoustic match.
export function engineVoice(rpm, load, speed, shifting, bonnet = false) {
 const r = Math.max(820, Math.min(6000, rpm)), l = Math.max(0, Math.min(1, load));
 return {pulseHz:r/40, crankHz:r/60, gain:(.06+l*.095)*(shifting?.55:1),
  cutoff:(bonnet?1050:760)+l*950+r*.12, intake:.006+l*.027,
  turboHz:Math.min(3200,1200+r*.27), turboGain:l*l*.004,
  rolling:Math.min(.038,Math.abs(speed)*.0016)};
}
export function createAudio(){
 let ctx,master,motor,filter,pulse,crank,intake,intakeFilter,roll,turbo,turboGain,enabled=true,volume=.35,soundscape,paused=true,music=true,city=true;
 const target=(param,v,t,k=.055)=>param.setTargetAtTime(v,t,k);
 function init(){
  if(ctx)return;ctx=new (window.AudioContext||window.webkitAudioContext)();
  master=ctx.createGain();master.gain.value=0;
  const compressor=ctx.createDynamicsCompressor();compressor.threshold.value=-15;compressor.ratio.value=4;
  master.connect(compressor);compressor.connect(ctx.destination);
  filter=ctx.createBiquadFilter();filter.type='lowpass';filter.Q.value=.65;filter.connect(master);
  motor=ctx.createGain();motor.gain.value=0;motor.connect(filter);
  // Rounded combustion pulses and harmonics avoid the old continuous sawtooth buzz.
  const real=new Float32Array(17),imag=new Float32Array(17);
  for(let n=1;n<17;n++){imag[n]=Math.exp(-n*.24)/Math.pow(n,.65);real[n]=Math.sin(n*1.2)*.09/n;}
  pulse=ctx.createOscillator();pulse.setPeriodicWave(ctx.createPeriodicWave(real,imag));pulse.frequency.value=20.5;pulse.connect(motor);pulse.start();
  crank=ctx.createOscillator();crank.type='triangle';crank.frequency.value=13.67;
  const crankGain=ctx.createGain();crankGain.gain.value=.24;crank.connect(crankGain);crankGain.connect(motor);crank.start();
  // A tiny deterministic noise buffer feeds intake air and the tires, separately filtered.
  const buffer=ctx.createBuffer(1,ctx.sampleRate*2,ctx.sampleRate),data=buffer.getChannelData(0);let seed=481;
  for(let i=0;i<data.length;i++){seed=(seed*1664525+1013904223)>>>0;data[i]=(seed/4294967296*2-1)*.65;}
  soundscape=createSoundscape(ctx,compressor,buffer);soundscape.setVolume(volume);soundscape.setMusic(music);soundscape.setCity(city);
  const noise=ctx.createBufferSource();noise.buffer=buffer;noise.loop=true;
  intakeFilter=ctx.createBiquadFilter();intakeFilter.type='bandpass';intakeFilter.frequency.value=650;intakeFilter.Q.value=.6;
  intake=ctx.createGain();intake.gain.value=0;noise.connect(intakeFilter);intakeFilter.connect(intake);intake.connect(master);
  const roadFilter=ctx.createBiquadFilter();roadFilter.type='lowpass';roadFilter.frequency.value=480;
  roll=ctx.createGain();roll.gain.value=0;noise.connect(roadFilter);roadFilter.connect(roll);roll.connect(master);noise.start();
  turbo=ctx.createOscillator();turbo.type='sine';turboGain=ctx.createGain();turboGain.gain.value=0;turbo.connect(turboGain);turboGain.connect(master);turbo.start();
 }
 function setEnabled(value){try{init();enabled=value;ctx.resume().catch(()=>{});target(master.gain,enabled?volume:0,ctx.currentTime,.08);}catch{enabled=false;}return enabled;}
 function update(state,stopped,bonnet=false,environment={}){paused=stopped;if(!ctx)return;const t=ctx.currentTime,v=engineVoice(state.rpm,state.load,state.speed,state.shifting,bonnet),active=paused?0:1;
  target(pulse.frequency,v.pulseHz,t);target(crank.frequency,v.crankHz,t);target(filter.frequency,v.cutoff,t);
  target(motor.gain,v.gain*active,t);target(intake.gain,v.intake*active,t);target(intakeFilter.frequency,550+state.rpm*.2,t);
  target(roll.gain,v.rolling*active,t);target(turbo.frequency,v.turboHz,t,.22);target(turboGain.gain,(v.turboGain+(state.boost?.008:0))*active,t,.18);
  soundscape.update({...environment,paused});
 }
 function tone(freq,duration,gain=.06,type='sine'){if(!ctx||!enabled||paused)return;const o=ctx.createOscillator(),g=ctx.createGain();o.type=type;o.frequency.value=freq;g.gain.setValueAtTime(gain,ctx.currentTime);g.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+duration);o.connect(g);g.connect(master);o.onended=()=>{o.disconnect();g.disconnect();};o.start();o.stop(ctx.currentTime+duration);}
 return{setEnabled,update,start(channels){music=channels.music;city=channels.ambience;setEnabled(channels.engine);soundscape?.setMusic(music);soundscape?.setCity(city);},setMusic(v){music=v;soundscape?.setMusic(v);},setCity(v){city=v;soundscape?.setCity(v);},status(){return {context:ctx?.state??'waiting for Play',engine:enabled,music,city,voices:soundscape?.activeVoices??0};},setVolume(v){volume=v;soundscape?.setVolume(v);if(ctx)target(master.gain,enabled?v:0,ctx.currentTime);},horn(){tone(392,.5,.13,'sawtooth');tone(490,.5,.07,'triangle');},tick(){tone(1000,.035,.12,'square');},bump(){tone(70,.15,.18,'triangle');}};
}
