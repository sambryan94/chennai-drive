export const BOOST_CAPACITY=8, BOOST_REFILL_PER_SECOND=.5;
export function createBoost(){
 let remaining=BOOST_CAPACITY,locked=false;
 return{update(dt,requested,eligible){
  if(!requested&&remaining>=1)locked=false;
  const active=requested&&eligible&&!locked&&remaining>1e-7;
  if(active){remaining=Math.max(0,remaining-dt);if(remaining<1e-7){remaining=0;locked=true;}}
  else remaining=Math.min(BOOST_CAPACITY,remaining+dt*BOOST_REFILL_PER_SECOND);
  return{boost:active,boostRemaining:remaining,boostLocked:locked};
 },get remaining(){return remaining;}};
}
