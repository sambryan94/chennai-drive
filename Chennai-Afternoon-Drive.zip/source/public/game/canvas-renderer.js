// Software 3D fallback. Same scene, cameras and physics, without GPU effects.
import * as T from './vendor/three.module.js';
export function createCanvasRenderer(canvas){
 const ctx=canvas.getContext('2d',{alpha:false});if(!ctx)throw new Error('Neither WebGL nor Canvas 2D is available.');
 let dynamicRevision=0,night=false,ratio=1,compiled=false,buffer,depthBuffer,pixels;const grid=new Map(),dynamic=[],labels=[];
 const v=new T.Vector3(),matrix=new T.Matrix4(),instance=new T.Matrix4(),sun=new T.Vector3(-.45,1,.45).normalize();
 const renderer={domElement:canvas,software:true,setNight(v){night=v;},shadowMap:{enabled:false,type:0},info:{render:{calls:1,triangles:0}},setPixelRatio(r){ratio=Math.min(r,.8);},setSize(w,h){const r=Math.min(ratio,Math.sqrt(800*450/(w*h)));canvas.width=Math.max(320,Math.floor(w*r));canvas.height=Math.max(200,Math.floor(h*r));buffer=ctx.createImageData(canvas.width,canvas.height);pixels=new Uint32Array(buffer.data.buffer);depthBuffer=new Float32Array(canvas.width*canvas.height);},render};
 function colorOf(material,ic,nx,ny,nz){const c=material.color?.clone()??new T.Color(0x9aab95);if(ic)c.multiply(ic);if(material.emissive){const amount=(material.emissiveIntensity??0)*.35;c.r=Math.min(1,c.r+material.emissive.r*amount);c.g=Math.min(1,c.g+material.emissive.g*amount);c.b=Math.min(1,c.b+material.emissive.b*amount);}c.convertLinearToSRGB();const light=material.isMeshBasicMaterial?1:.69+.31*Math.max(0,nx*sun.x+ny*sun.y+nz*sun.z);return (255<<24)|(Math.round(c.b*255*light)<<16)|(Math.round(c.g*255*light)<<8)|Math.round(c.r*255*light);}
 function triangles(mesh,transform,ic,emit){const pos=mesh.geometry.attributes.position,index=mesh.geometry.index,count=index?index.count:pos.count;for(let i=0;i<count;i+=3){const points=[];for(let j=0;j<3;j++){const k=index?index.getX(i+j):i+j;v.fromBufferAttribute(pos,k).applyMatrix4(transform);points.push(v.x,v.y,v.z);}const ax=points[3]-points[0],ay=points[4]-points[1],az=points[5]-points[2],bx=points[6]-points[0],by=points[7]-points[1],bz=points[8]-points[2];let nx=ay*bz-az*by,ny=az*bx-ax*bz,nz=ax*by-ay*bx;const len=Math.hypot(nx,ny,nz)||1;nx/=len;ny/=len;nz/=len;emit({p:points,n:[nx,ny,nz],color:colorOf(mesh.material,ic,nx,ny,nz),sky:!!mesh.userData.sky,unlit:!!mesh.material.isMeshBasicMaterial,double:mesh.material.side===T.DoubleSide});}}
 function add(tri){const x=Math.floor((tri.p[0]+tri.p[3]+tri.p[6])/300),z=Math.floor((tri.p[2]+tri.p[5]+tri.p[8])/300),key=x+','+z;if(!grid.has(key))grid.set(key,[]);grid.get(key).push(tri);}
 function compile(scene){scene.updateMatrixWorld(true);scene.traverse(mesh=>{if(!mesh.isMesh||mesh.material?.transparent||mesh.geometry?.parameters?.width>5000)return;let parent=mesh,dyn=false;while(parent){dyn||=!!parent.userData.dynamic;parent=parent.parent;}if(dyn){dynamic.push(mesh);return;}if(mesh.userData.label){labels.push(mesh);return;}if(mesh.isInstancedMesh){const ic=new T.Color();for(let i=0;i<mesh.count;i++){mesh.getMatrixAt(i,instance);matrix.multiplyMatrices(mesh.matrixWorld,instance);if(mesh.instanceColor)mesh.getColorAt(i,ic);triangles(mesh,matrix,mesh.instanceColor?ic:null,add);}}else triangles(mesh,mesh.matrixWorld,null,add);});compiled=true;}
 function render(scene,camera){if(!compiled)compile(scene);if(dynamicRevision!==(scene.userData.dynamicRevision??0)){dynamicRevision=scene.userData.dynamicRevision;dynamic.length=0;scene.traverse(mesh=>{if(!mesh.isMesh||mesh.material?.transparent)return;let p=mesh;while(p){if(p.userData.dynamic){dynamic.push(mesh);break;}p=p.parent;}});}scene.updateMatrixWorld(true);camera.updateMatrixWorld(true);const e=camera.matrixWorldInverse.elements,cp=camera.position,fx=canvas.height/(2*Math.tan(camera.fov*Math.PI/360)),cx=canvas.width/2,cy=canvas.height*(.5-(camera.view?.enabled?camera.view.offsetY/camera.view.fullHeight:0));
  pixels.fill(night?0xff3a2318:0xffd3d7c2);depthBuffer.fill(0);const dir=new T.Vector3();camera.getWorldDirection(dir);const horizon=cy+dir.y*fx/Math.max(.1,Math.hypot(dir.x,dir.z));pixels.fill(night?0xff403133:0xff83a39c,Math.min(pixels.length,Math.max(0,Math.floor(horizon))*canvas.width));
  const queue=[];let total=0;
  function project(tri){const p=tri.p,n=tri.n;if(!tri.double&&n[0]*(cp.x-p[0])+n[1]*(cp.y-p[1])+n[2]*(cp.z-p[2])<0)return;const poly=[];for(let i=0;i<9;i+=3){const x=p[i],y=p[i+1],z=p[i+2];poly.push([e[0]*x+e[4]*y+e[8]*z+e[12],e[1]*x+e[5]*y+e[9]*z+e[13],e[2]*x+e[6]*y+e[10]*z+e[14]]);}if(poly.every(a=>a[2]>-.12)||poly.every(a=>a[2]<-330))return;
   const clipped=[];for(let i=0;i<poly.length;i++){const a=poly[i],b=poly[(i+1)%poly.length],ain=a[2]<-.12,bin=b[2]<-.12;if(ain)clipped.push(a);if(ain!==bin){const t=(-.12-a[2])/(b[2]-a[2]);clipped.push([a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,-.12]);}}
   if(clipped.length<3)return;const screen=clipped.map(a=>[cx-a[0]/a[2]*fx,cy+a[1]/a[2]*fx,-1/a[2]]);if(screen.every(a=>a[0]<0)||screen.every(a=>a[0]>canvas.width)||screen.every(a=>a[1]<0)||screen.every(a=>a[1]>canvas.height))return;
   const depth=-clipped.reduce((s,a)=>s+a[2],0)/clipped.length;let color=tri.color;if(night&&!tri.unlit){const x=(p[0]+p[3]+p[6])/3,z=(p[2]+p[5]+p[8])/3;let r=.42,g=.45,b=.62;for(const light of scene.userData.nightLights??[]){const dx=x-light.x,dz=z-light.z,fall=Math.max(0,1-(dx*dx+dz*dz)/(light.radius*light.radius));r+=fall*light.r;g+=fall*light.g;b+=fall*light.b;}const fog=Math.min(.83,Math.max(0,depth-45)/330);const red=Math.min(255,(color&255)*r)*(1-fog)+24*fog,green=Math.min(255,((color>>>8)&255)*g)*(1-fog)+35*fog,blue=Math.min(255,((color>>>16)&255)*b)*(1-fog)+58*fog;color=(255<<24)|(Math.round(blue)<<16)|(Math.round(green)<<8)|Math.round(red);}queue.push({screen,depth,color,sky:tri.sky});total++;
  }
  const gx=Math.floor(cp.x/100),gz=Math.floor(cp.z/100);for(let dx=-4;dx<=4;dx++)for(let dz=-4;dz<=4;dz++){const tris=grid.get((gx+dx)+','+(gz+dz));if(tris)for(const tri of tris)project(tri);}
  for(const mesh of dynamic){let root=mesh,visible=true;while(root){if(!root.visible){visible=false;break;}root=root.parent;}if(visible)triangles(mesh,mesh.matrixWorld,null,project);}
  function raster(a,b,c,color,sky=false){
   const width=canvas.width,height=canvas.height,area=(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);if(Math.abs(area)<.001)return;
   const minX=Math.max(0,Math.floor(Math.min(a[0],b[0],c[0]))),maxX=Math.min(width-1,Math.ceil(Math.max(a[0],b[0],c[0]))),minY=Math.max(0,Math.floor(Math.min(a[1],b[1],c[1]))),maxY=Math.min(height-1,Math.ceil(Math.max(a[1],b[1],c[1])));
   const inv=1/area,ax=(b[1]-c[1])*inv,ay=(c[0]-b[0])*inv,bx=(c[1]-a[1])*inv,by=(a[0]-c[0])*inv;
   for(let y=minY;y<=maxY;y++){if(sky&&y>horizon)continue;let wa=((b[0]-minX-.5)*(c[1]-y-.5)-(b[1]-y-.5)*(c[0]-minX-.5))*inv,wb=((c[0]-minX-.5)*(a[1]-y-.5)-(c[1]-y-.5)*(a[0]-minX-.5))*inv;let index=y*width+minX;for(let x=minX;x<=maxX;x++,index++,wa+=ax,wb+=bx){const wc=1-wa-wb;if(wa>=-.00001&&wb>=-.00001&&wc>=-.00001){const z=wa*a[2]+wb*b[2]+wc*c[2];if(z>depthBuffer[index]){if(!sky)depthBuffer[index]=z;pixels[index]=color;}}}}
  }
  queue.sort((a,b)=>Number(b.sky)-Number(a.sky));for(const item of queue)for(let i=1;i<item.screen.length-1;i++)raster(item.screen[0],item.screen[i],item.screen[i+1],item.color,item.sky);
  ctx.putImageData(buffer,0,0);
  for(const label of labels){
   v.setFromMatrixPosition(label.matrixWorld);if(v.distanceTo(cp)>140)continue;v.applyMatrix4(camera.matrixWorldInverse);if(v.z>=-1)continue;
   const x=cx-v.x/v.z*fx,y=cy+v.y/v.z*fx,depth=-v.z;
   if(x<0||x>=canvas.width||y<0||y>=canvas.height)continue;
   if(depthBuffer[Math.floor(y)*canvas.width+Math.floor(x)]>1/(depth-.8))continue;
   const corners=[[-.5,-.5],[.5,-.5],[.5,.5],[-.5,.5]].map(([px,py])=>new T.Vector3(px*label.geometry.parameters.width,py*label.geometry.parameters.height,0).applyMatrix4(label.matrixWorld).applyMatrix4(camera.matrixWorldInverse));
   if(corners.some(p=>p.z>-.5))continue;
   const screen=corners.map(p=>[cx-p.x/p.z*fx,cy+p.y/p.z*fx]),w=Math.hypot(screen[1][0]-screen[0][0],screen[1][1]-screen[0][1]);if(w<10)continue;
   ctx.fillStyle=night?'#25132e':label.userData.signColor||'#2c5255';ctx.beginPath();screen.forEach((p,i)=>i?ctx.lineTo(...p):ctx.moveTo(...p));ctx.closePath();ctx.fill();
   ctx.font=Math.max(6,Math.min(16,label.geometry.parameters.height*fx/depth*.6))+'px Arial';ctx.textBaseline='middle';ctx.textAlign='center';ctx.fillStyle=night?'#ff70b1':'#fff3d9';ctx.shadowColor='#fd287f';ctx.shadowBlur=night?7:0;ctx.fillText(label.userData.label,x,y,w*.91);
  }
  ctx.shadowBlur=0;renderer.info.render.triangles=total;
 }
 return renderer;
}
