import * as T from './vendor/three.module.js';
// Contact impulses are solved by cannon-es; this module only presents their effects.
export function createCrashFeedback(physics,traffic,container,audio){
 let time=0,last=-10,kick=0,count=0,lastSpeed=0;const bubbles=traffic.items.map(item=>{const el=document.createElement('span');el.className='angry-driver';el.textContent='😡';el.setAttribute('aria-label','Angry driver after collision');el.hidden=true;container.append(el);return{item,el};});
 physics.chassis.addEventListener('collide',e=>{const speed=Math.abs(e.contact.getImpactVelocityAlongNormal());if(speed<2.2||!['traffic','building','tree'].includes(e.body.propType)||time-last<.35)return;last=time;kick=Math.min(.14,speed*.006);lastSpeed=speed;count++;audio.bump();});
 const point=new T.Vector3();
 return{update(dt,camera){time+=dt;kick*=Math.exp(-10*dt);for(const {item,el}of bubbles){if(item.angry<=0||!item.group.visible){el.hidden=true;continue;}point.set(item.body.position.x,item.bus?4.2:2.6,item.body.position.z);const distance=point.distanceTo(camera.position);point.project(camera);const visible=distance<85&&point.z>-1&&point.z<1&&Math.abs(point.x)<.95&&Math.abs(point.y)<.95;el.hidden=!visible;if(visible){el.style.left=(point.x*.5+.5)*100+'%';el.style.top=(-point.y*.5+.5)*100+'%';el.style.opacity=String(Math.min(1,item.angry));el.style.fontSize=Math.max(20,Math.min(40,350/distance))+'px';}}},get kick(){return kick;},get count(){return count;},get lastSpeed(){return lastSpeed;}};
}
