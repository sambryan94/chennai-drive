import * as T from './vendor/three.module.js';
// Bevels change the silhouette and catch highlights; no texture downloads required.
const cache=new Map();
export function roundedBox(w,h,d,r=Math.min(w,h,d)*.14){
 const key=[w,h,d,r].join(',');if(cache.has(key))return cache.get(key);
 r=Math.min(r,w*.24,h*.24,d*.24);const s=new T.Shape(),x=-w/2+r,y=-h/2+r,ww=w-2*r,hh=h-2*r;
 s.moveTo(x,y);s.lineTo(x+ww,y);s.lineTo(x+ww,y+hh);s.lineTo(x,y+hh);s.closePath();
 const g=new T.ExtrudeGeometry(s,{depth:d-2*r,bevelEnabled:true,bevelSegments:2,steps:1,bevelSize:r,bevelThickness:r,curveSegments:2});g.translate(0,0,-d/2+r);g.computeVertexNormals();cache.set(key,g);return g;
}
export function setDetailVisible(root,enabled){root.traverse(m=>{if(m.userData.detail)m.visible=enabled;});}

export function cabinGeometry(w,h,d){
 const x=w/2,y=h/2,z=d/2;const vertices=[-x,-y,-z,x,-y,-z,x,-y,z,-x,-y,z,-x*.9,y,-z+.34,x*.9,y,-z+.34,x*.9,y,z-.12,-x*.9,y,z-.12];
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(vertices,3));g.setIndex([0,4,5,0,5,1,1,5,6,1,6,2,2,6,7,2,7,3,3,7,4,3,4,0,4,7,6,4,6,5,0,1,2,0,2,3]);const flat=g.toNonIndexed();flat.computeVertexNormals();g.dispose();return flat;
}
