// Functional SVG instruments: crisp at every display size, no image assets.
const NS='http://www.w3.org/2000/svg';
const point=(angle,r)=>({x:110+Math.cos(angle*Math.PI/180)*r,y:105+Math.sin(angle*Math.PI/180)*r});
export function gaugeAngle(value,max){return 135+Math.max(0,Math.min(max,value))/max*270;}
export function createInstruments(speedHost,rpmHost){
 function dial(host,max,step,label,redStart=Infinity){
  const svg=document.createElementNS(NS,'svg');svg.setAttribute('viewBox','0 0 220 200');svg.setAttribute('role','img');svg.setAttribute('aria-label',label);svg.classList.add('analogue-dial');
  const el=(tag,attrs)=>{const n=document.createElementNS(NS,tag);for(const [k,v]of Object.entries(attrs))n.setAttribute(k,String(v));svg.append(n);return n;};
  el('circle',{cx:110,cy:105,r:94,fill:'#10292f',stroke:'#527477','stroke-width':2});
  el('circle',{cx:110,cy:105,r:88,fill:'none',stroke:'#ffffff12','stroke-width':1});
  for(let v=0;v<=max+.001;v+=step/4){const major=Math.abs(v/step-Math.round(v/step))<.01,a=gaugeAngle(v,max),p=point(a,84),q=point(a,major?72:78);el('line',{x1:p.x,y1:p.y,x2:q.x,y2:q.y,stroke:v>=redStart?'#f48973':major?'#e0e7dd':'#73938e','stroke-width':major?2.3:1});
   if(major){const t=point(a,59),text=el('text',{x:t.x,y:t.y+4,'text-anchor':'middle',fill:'#e2e9df','font-size':13,'font-family':'Arial'});text.textContent=v;}}
  const unit=el('text',{x:110,y:75,'text-anchor':'middle',fill:'#adc4bb','font-size':11,'letter-spacing':1});unit.textContent=label;
  const needle=el('g',{'data-needle':label,transform:'rotate(135 110 105)'});const path=document.createElementNS(NS,'path');path.setAttribute('d','M 99 102 L 185 105 L 99 108 Z');path.setAttribute('fill','#ffa675');needle.append(path);
  el('circle',{cx:110,cy:105,r:7,fill:'#f4c29b',stroke:'#193a3e','stroke-width':3});host.prepend(svg);
  return{set(value){needle.setAttribute('transform',`rotate(${gaugeAngle(value,max)} 110 105)`);svg.setAttribute('aria-label',`${label}: ${Math.round(value*10)/10}`);}};
 }
 const speed=dial(speedHost,200,20,'km/h'),rpm=dial(rpmHost,7,1,'RPM × 1000',5.5);
 return{update(state){speed.set(Math.abs(state.speed)*3.6);rpm.set(state.rpm/1000);}};
}
