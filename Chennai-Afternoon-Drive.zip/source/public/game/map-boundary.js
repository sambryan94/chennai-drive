import * as T from './vendor/three.module.js';
import {MAP_BOUNDS,insideMap} from './roads.js';
// Continuous solid perimeter; subdivision keeps collision activation inexpensive.
export function createMapBoundary(scene,physics){
 const b=MAP_BOUNDS,segments=[],corners=[[b.minX,b.minZ],[b.maxX,b.minZ],[b.maxX,b.maxZ],[b.minX,b.maxZ]];
 for(let side=0;side<4;side++){const a=corners[side],z=corners[(side+1)%4],length=Math.hypot(z[0]-a[0],z[1]-a[1]),count=Math.ceil(length/35),angle=Math.atan2(z[0]-a[0],z[1]-a[1]);for(let i=0;i<count;i++){const t=(i+.5)/count,x=a[0]+(z[0]-a[0])*t,y=a[1]+(z[1]-a[1])*t,body=physics.box(x,y,1.4,length/count+.1,2.8,0,angle);body.propType='boundary';segments.push({x,z:y,length:length/count+.1,angle,body});}}
 const geo=new T.BoxGeometry(1,1,1),mat=new T.MeshStandardMaterial({color:0xccb890,roughness:.9}),mesh=new T.InstancedMesh(geo,mat,segments.length),caps=new T.InstancedMesh(geo,new T.MeshBasicMaterial({color:0xc47442}),segments.length),tmp=new T.Object3D();
 segments.forEach((s,i)=>{tmp.position.set(s.x,1.4,s.z);tmp.scale.set(1.4,2.8,s.length);tmp.rotation.y=s.angle;tmp.updateMatrix();mesh.setMatrixAt(i,tmp.matrix);tmp.position.y=2.84;tmp.scale.y=.12;tmp.updateMatrix();caps.setMatrixAt(i,tmp.matrix);});mesh.computeBoundingSphere();caps.computeBoundingSphere();scene.add(mesh,caps);
 return{bounds:b,segments,contains:insideMap};
}
