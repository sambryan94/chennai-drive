import {MAP_BOUNDS} from './roads.js';
// A single uniform world-to-map transform keeps the road geometry and marker aligned.
export function fitMap(points,width,height,padding=22){
 const xs=points.map(p=>p.x),zs=points.map(p=>p.z),minX=Math.min(...xs),maxX=Math.max(...xs),minZ=Math.min(...zs),maxZ=Math.max(...zs);
 const scale=Math.min((width-padding*2)/Math.max(1,maxX-minX),(height-padding*2)/Math.max(1,maxZ-minZ));
 const x=width/2-(minX+maxX)/2*scale,y=height/2-(minZ+maxZ)/2*scale;
 return{scale,project:(wx,wz)=>({x:wx*scale+x,y:wz*scale+y})};
}
export function createMinimap(canvas,world){
 const ctx=canvas.getContext('2d'),points=[...world.roads.flatMap(r=>r.points),{x:MAP_BOUNDS.minX,z:MAP_BOUNDS.minZ},{x:MAP_BOUNDS.maxX,z:MAP_BOUNDS.maxZ}];let width=0,height=0,projection;
 function draw(position,heading){
  const rect=canvas.getBoundingClientRect(),w=Math.round(rect.width),h=Math.round(rect.height);if(!w||!h)return;
  const dpr=Math.min(window.devicePixelRatio||1,2);
  if(width!==w||height!==h||canvas.width!==Math.round(w*dpr)){width=w;height=h;canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);projection=fitMap(points,w,h,w<180?16:24);}
  ctx.setTransform(dpr,0,0,dpr,0,0);ctx.fillStyle='#16363e';ctx.fillRect(0,0,w,h);
  ctx.strokeStyle='#25474b';ctx.lineWidth=.5;for(let i=0;i<w;i+=24){ctx.beginPath();ctx.moveTo(i,0);ctx.lineTo(i,h);ctx.stroke();}for(let i=0;i<h;i+=24){ctx.beginPath();ctx.moveTo(0,i);ctx.lineTo(w,i);ctx.stroke();}
  for(let pass=0;pass<2;pass++){ctx.lineWidth=pass?2:6;ctx.lineJoin='round';for(const road of world.roads){ctx.lineWidth=road.interior?(pass?1:2.5):(pass?2:5);ctx.strokeStyle=pass?(road.name==='Velachery Main Road'?'#ecd2a9':'#a8bfbc'):'#426164';ctx.beginPath();road.points.forEach((p,i)=>{const q=projection.project(p.x,p.z);i?ctx.lineTo(q.x,q.y):ctx.moveTo(q.x,q.y);});ctx.stroke();}}
  ctx.setLineDash([3,3]);ctx.strokeStyle='#e4ab73';ctx.lineWidth=1;const edge=projection.project(MAP_BOUNDS.minX,MAP_BOUNDS.minZ),far=projection.project(MAP_BOUNDS.maxX,MAP_BOUNDS.maxZ);ctx.strokeRect(edge.x,edge.y,far.x-edge.x,far.y-edge.y);ctx.setLineDash([]);
  ctx.font=(w<180?'9':'11')+'px Arial';ctx.textBaseline='bottom';
  for(const place of world.places.slice(0,4)){const p=projection.project(place.x,place.z),label=place.name==='Phoenix Marketcity'?'Phoenix':place.name==='Kathipara vicinity'?'Kathipara':place.name;
   const tw=ctx.measureText(label).width,x=Math.min(w-tw-5,Math.max(5,p.x+7)),y=Math.max(15,p.y-7);
   ctx.fillStyle='#16363ee8';ctx.fillRect(x-2,y-12,tw+4,14);ctx.fillStyle='#d1dfd2';ctx.fillText(label,x,y);
  }
  const p=projection.project(position.x,position.z);ctx.save();ctx.translate(Math.max(7,Math.min(w-7,p.x)),Math.max(7,Math.min(h-7,p.y)));ctx.rotate(heading);
  ctx.strokeStyle='#102e36';ctx.lineWidth=2;ctx.fillStyle='#ffa675';ctx.beginPath();ctx.moveTo(0,-7);ctx.lineTo(5,5);ctx.lineTo(0,2);ctx.lineTo(-5,5);ctx.closePath();ctx.stroke();ctx.fill();ctx.restore();
 }
 return{draw};
}
