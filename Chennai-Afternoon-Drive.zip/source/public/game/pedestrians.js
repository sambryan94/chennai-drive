import {roundedBox} from './geometry.js';
import * as T from './vendor/three.module.js';
import {prepareTrafficRoutes,sampleLane} from './route-utils.js';
export const PEDESTRIAN_COUNT=56;
export function createPedestrians(scene,roads,signals){
 const routes=prepareTrafficRoutes(roads),items=[],geo=roundedBox(1,1,1,.15),skin=new T.MeshStandardMaterial({color:0xa57350}),dark=new T.MeshStandardMaterial({color:0x233747}),shirts=[0xc77560,0x3b8c9b,0xd7b75b,0xc6cbd2,0x915b88].map(color=>new T.MeshStandardMaterial({color}));
 for(let i=0;i<PEDESTRIAN_COUNT;i++){const group=new T.Group();group.userData.dynamic=true;const legs=[],arms=[];function part(w,h,d,x,y,z,mat){const m=new T.Mesh(geo,mat);m.scale.set(w,h,d);m.position.set(x,y,z);group.add(m);return m;}
  part(.38,.62,.25,0,1.14,0,shirts[i%shirts.length]);const head=new T.Mesh(new T.SphereGeometry(1,12,8),skin);head.position.set(0,1.63,0);head.scale.set(.14,.17,.14);group.add(head);const hair=new T.Mesh(new T.SphereGeometry(1,12,6,0,Math.PI*2,0,Math.PI*.48),dark);hair.position.set(0,1.68,0);hair.scale.set(.145,.14,.145);group.add(hair);for(const side of [-1,1])part(.15,.09,.26,side*.11,.075,-.035,dark);for(const side of [-1,1]){legs.push(part(.14,.78,.16,side*.11,.46,0,dark));arms.push(part(.11,.6,.13,side*.255,1.1,0,skin));}scene.add(group);
  const routeIndex=i%routes.length,r=routes[routeIndex],crossing=i<signals.junctions.length*2?signals.junctions[i%signals.junctions.length]:null;
  items.push({id:1000+i,group,legs,arms,routeIndex,distance:r.length*((i*.117+.19)%1),direction:i%2?1:-1,speed:1.1+(i%4)*.13,crossing,progress:i%2?1:0,walking:false,side:i%2?1:-1,x:0,z:0});
 }
 let time=0;
 function update(dt,player){time+=dt;for(const p of items){let pose;
  if(p.crossing){const c=p.crossing.crossing,total=c.width+4;const playerDist=Math.hypot(player.position.x-c.x,player.position.z-c.z);if(!p.walking&&signals.canWalk(p.crossing)&&playerDist>35){p.walking=true;p.progress=p.side===1?1:0;}
   if(p.walking){p.progress+=dt*1.9/total*p.side*-1;if(p.progress<=0||p.progress>=1){p.progress=Math.max(0,Math.min(1,p.progress));p.walking=false;p.side*=-1;}}
   const lateral=(p.progress-.5)*total;pose={x:c.x+c.fz*lateral,z:c.z-c.fx*lateral,heading:Math.atan2(-c.fz*p.side,c.fx*p.side)};
  }else{const r=routes[p.routeIndex];p.distance+=p.speed*dt*p.direction;if(p.distance<15||p.distance>r.length-15){p.direction*=-1;p.distance=Math.max(15,Math.min(r.length-15,p.distance));}pose=sampleLane({...r,oneway:0,width:(r.width/2+2.8)/.23},p.distance,p.direction);}
  p.x=pose.x;p.z=pose.z;p.group.position.set(p.x,0,p.z);p.group.rotation.y=pose.heading;p.group.visible=Math.hypot(p.x-player.position.x,p.z-player.position.z)<170;const swing=!p.crossing||p.walking?Math.sin(time*5+p.id)*.36:0;p.legs[0].rotation.x=swing;p.legs[1].rotation.x=-swing;p.arms[0].rotation.x=-swing*.7;p.arms[1].rotation.x=swing*.7;
 }}
 return{items,update,get crossings(){return items.filter(p=>p.crossing&&p.walking).map(p=>({id:p.id,x:p.x,z:p.z,length:.8}));}};
}
