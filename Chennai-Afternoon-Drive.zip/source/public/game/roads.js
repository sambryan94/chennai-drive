// Geographic road vertices from a bounded OpenStreetMap export, ODbL 1.0.
import {OSM_ROADS,MAP_META} from './data/roads-data.js';
export {MAP_META};
export const ROAD_DATA=OSM_ROADS;
const metres=111195.0802335329,longitudeScale=metres*Math.cos(MAP_META.origin.lat*Math.PI/180);
export function fromGeo(lat,lon){return{x:(lon-MAP_META.origin.lon)*longitudeScale,z:(MAP_META.origin.lat-lat)*metres};}
export function toGeo(x,z){return{lat:MAP_META.origin.lat-z/metres,lon:MAP_META.origin.lon+x/longitudeScale};}
export const SPAWN=fromGeo(12.9897,80.2212);
export const PLACES=[
 {name:'Velachery · Vijayanagar',...fromGeo(12.975951,80.2210664),osmId:'node/278744710'},
 {name:'Phoenix Marketcity',...fromGeo(12.9915311,80.2166832),osmId:'relation/15321422'},
 {name:'Guindy',...fromGeo(13.0080474,80.2131366),osmId:'node/9920341495'},
 {name:'Kathipara approach',...fromGeo(13.0086,80.2059)},
 {name:'Rajalakshmi Nagar',...fromGeo(12.9852883,80.2187428),osmId:'node/4304426158'}
];
export const LANDMARKS=[{name:'PHOENIX MARKETCITY',...fromGeo(12.9915311,80.2166832),w:108,d:236,h:20,color:0xdfcfba,style:'mall',osmId:'relation/15321422'}];
const all=ROAD_DATA.flatMap(r=>r.points);
export const MAP_BOUNDS={minX:Math.min(...all.map(p=>p[0]))-45,maxX:Math.max(...all.map(p=>p[0]))+45,minZ:Math.min(...all.map(p=>p[1]))-45,maxZ:Math.max(...all.map(p=>p[1]))+45};
export function insideMap(x,z,margin=0){return x>=MAP_BOUNDS.minX+margin&&x<=MAP_BOUNDS.maxX-margin&&z>=MAP_BOUNDS.minZ+margin&&z<=MAP_BOUNDS.maxZ-margin;}
// Sample straight between OSM vertices; never use curves that move actual junctions.
export function roadPoints(road,step=9){const out=[];for(let i=0;i<road.points.length-1;i++){const a=road.points[i],b=road.points[i+1],len=Math.hypot(b[0]-a[0],b[1]-a[1]);if(len<.001)continue;const n=Math.ceil(len/step);for(let j=0;j<n;j++)out.push({x:a[0]+(b[0]-a[0])*j/n,z:a[1]+(b[1]-a[1])*j/n});}const last=road.points.at(-1);out.push({x:last[0],z:last[1]});return out;}
export function roadClearance(roads,x,z){let clearance=Infinity;for(const r of roads){const n=nearestOnRoad([r],x,z);clearance=Math.min(clearance,n.distance-r.width/2);}return clearance;}
export function footprintClear(roads,x,z,w,d,ry,margin=.8){const c=Math.cos(ry),s=Math.sin(ry);for(const lx of [-w/2,0,w/2])for(const lz of [-d/2,0,d/2])if(roadClearance(roads,x+c*lx+s*lz,z-s*lx+c*lz)<margin)return false;return true;}
export function nearestOnRoad(roads,x,z) {
 let best={distance:Infinity,x:0,z:0,heading:0,width:20,road:null,index:0};
 for(const road of roads) for(let i=0;i<road.points.length-1;i++){
  const a=road.points[i],b=road.points[i+1],dx=b.x-a.x,dz=b.z-a.z;
  const t=Math.max(0,Math.min(1,((x-a.x)*dx+(z-a.z)*dz)/(dx*dx+dz*dz)));
  const px=a.x+dx*t,pz=a.z+dz*t,dist=Math.hypot(x-px,z-pz);
  if(dist<best.distance)best={distance:dist,x:px,z:pz,heading:Math.atan2(-dx,-dz),width:road.width,road,index:i};
 }
 return best;
}
