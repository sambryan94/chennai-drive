export function sampleLane(route, distance, direction = 1) {
 const d=Math.max(0,Math.min(route.length-.001,distance));
 let lo=0,hi=route.cumulative.length-1;
 while(lo+1<hi){const mid=(lo+hi)>>1;if(route.cumulative[mid]<=d)lo=mid;else hi=mid;}
 const a=route.points[lo],b=route.points[lo+1],len=route.cumulative[lo+1]-route.cumulative[lo],t=(d-route.cumulative[lo])/len;
 const fx=(b.x-a.x)/len*direction,fz=(b.z-a.z)/len*direction,lane=route.oneway?0:route.width*.23;
 // Keep left: left normal of the travel vector in X east / Z south coordinates.
 return {x:a.x+(b.x-a.x)*t+fz*lane,z:a.z+(b.z-a.z)*t-fx*lane,fx,fz,heading:Math.atan2(-fx,-fz)};
}
export function prepareTrafficRoutes(roads){return roads.map(r=>{const cumulative=[0];for(let i=1;i<r.points.length;i++)cumulative.push(cumulative.at(-1)+Math.hypot(r.points[i].x-r.points[i-1].x,r.points[i].z-r.points[i-1].z));return {...r,cumulative,length:cumulative.at(-1)};});}
