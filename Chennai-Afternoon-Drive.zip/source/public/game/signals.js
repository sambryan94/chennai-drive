import * as T from './vendor/three.module.js';
import {prepareTrafficRoutes,sampleLane} from './route-utils.js';
import {fromGeo,roadClearance} from './roads.js';
const LOCATIONS=[[12.983,80.222,'Dhandeeswaram crossing'],[12.9761,80.22133,'Vijayanagar junction'],[12.9915,80.21955,'Phoenix / bypass junction'],[13.0121,80.2217,'Guindy approach'],[12.9853,80.21825,'Rajalakshmi Nagar junction']].map(([lat,lon,name])=>{const p=fromGeo(lat,lon);return[p.x,p.z,name];});
export function signalPhase(time,groups,index){const cycle=groups*17+18,t=((time%cycle)+cycle)%cycle,slot=Math.floor(t/17);if(t>=groups*17)return t<groups*17+16?'walk':'red';if(slot!==index)return'red';return t%17<12?'green':t%17<15?'amber':'red';}
export function createSignals(scene,physics,roads){
 const routes=prepareTrafficRoutes(roads),junctions=[],box=new T.BoxGeometry(1,1,1),lamp=new T.SphereGeometry(.15,6,4);
 const poleMat=new T.MeshStandardMaterial({color:0x404d58}),black=new T.MeshStandardMaterial({color:0x16222b});let time=0;
 for(const [x,z,name]of LOCATIONS){const approaches=[];routes.forEach((r,routeIndex)=>{let best=Infinity,d=0;for(let i=0;i<r.points.length;i++){const p=r.points[i],dist=Math.hypot(p.x-x,p.z-z);if(dist<best){best=dist;d=r.cumulative[i];}}if(best<45&&r.length>65)approaches.push({routeIndex,distance:d,stops:{}});});if(!approaches.length)continue;
  const junction={x,z,name,approaches,heads:[],index:junctions.length};junctions.push(junction);
  approaches.forEach((a,groupIndex)=>{for(const direction of [-1,1]){
   const route=routes[a.routeIndex];if(route.oneway&&direction!==route.oneway)continue;
   let placement=null;
   // Test the complete carriageway union, including crossing roads and dual lanes.
   for(const back of [26,38,50,64,80]){const distance=a.distance-direction*back;if(distance<8||distance>route.length-8)continue;const centre=sampleLane({...route,width:0},distance,direction);for(const edge of [1,-1]){const side=route.width/2+1.8,px=centre.x+centre.fz*side*edge,pz=centre.z-centre.fx*side*edge;if(roadClearance(roads,px,pz)>1){placement={px,pz,distance,pose:sampleLane(route,distance,direction)};break;}}if(placement)break;}
   if(!placement)continue;
   const {px,pz,distance,pose:p}=placement;a.stops[direction]=distance;
   const g=new T.Group();g.userData.dynamic=true;g.position.set(px,0,pz);g.rotation.y=p.heading;scene.add(g);
   const part=(w,h,d,y,mat,zz=0)=>{const m=new T.Mesh(box,mat);m.scale.set(w,h,d);m.position.set(0,y,zz);g.add(m);return m;};
   part(.16,4.5,.16,2.25,poleMat);part(.62,1.55,.35,4.05,black);const lamps={};
   for(const [color,y,value]of [['red',4.54,0xff365f],['amber',4.05,0xffb54f],['green',3.56,0x45ffc4]]){const material=new T.MeshBasicMaterial({color:value}),m=new T.Mesh(lamp,material);m.position.set(0,y,.22);g.add(m);lamps[color]=m;}
   const walk=part(.4,.35,.35,2.8,new T.MeshBasicMaterial({color:0xff365f}),.03);
   const line=new T.Mesh(new T.BoxGeometry(route.width*.44,.02,.27),new T.MeshBasicMaterial({color:0xe2dec7}));line.position.set(p.x,.07,p.z);line.rotation.y=p.heading;scene.add(line);
   const body=physics.box(px,pz,.26,.26,4.6);body.propType='signal';junction.heads.push({groupIndex,direction,distance,lamps,walk,g,body});
  }});
  const route=routes[approaches[0].routeIndex],pose=sampleLane({...route,width:0},approaches[0].distance,1);junction.crossing={...pose,width:route.width};
  const stripes=new T.Group();stripes.rotation.y=pose.heading;stripes.position.set(pose.x,.076,pose.z);for(let i=-Math.floor(route.width/2)+1;i<route.width/2;i+=1.4){const m=new T.Mesh(box,new T.MeshBasicMaterial({color:0xd3d6c5}));m.scale.set(.75,.018,3.4);m.position.x=i;stripes.add(m);}scene.add(stripes);
 }
 function phase(j,index){return signalPhase(time+j.index*4,j.approaches.length,index);}
 function update(dt){time+=dt;for(const j of junctions)for(const h of j.heads){const p=phase(j,h.groupIndex);for(const [color,m]of Object.entries(h.lamps)){m.visible=p===color||(p==='walk'&&color==='red');m.material.color.setHex({red:0xff365f,amber:0xffb54f,green:0x45ffc4}[color]);}h.walk.material.color.setHex(p==='walk'?0x45ffc4:0x713444);}}
 function speedLimit(item){let limit=Infinity;for(const j of junctions){const group=j.approaches.findIndex(a=>a.routeIndex===item.routeIndex);if(group<0)continue;const a=j.approaches[group],stop=a.stops[item.direction];if(stop===undefined)continue;const ahead=(stop-item.distance)*item.direction;if(ahead< -item.length||ahead>110)continue;const p=phase(j,group),clearance=ahead-item.length/2-1;
  if(p==='green'||(p==='amber'&&clearance<item.speed*item.speed/10+3))continue;limit=Math.min(limit,Math.max(0,clearance*.65));}return limit;}
 function canWalk(j){const t=(time+j.index*4)%(j.approaches.length*17+18);return t>=j.approaches.length*17&&t<j.approaches.length*17+2;}
 update(0);return{junctions,routes,update,speedLimit,canWalk,phase,get time(){return time;}};
}
