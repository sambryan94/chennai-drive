import * as T from './vendor/three.module.js';
// Bounded random ambient events. Timers advance only with active gameplay.
export function createSkySchedule(random=Math.random){
 let night=false,time=0;const active=[],next={flight:8+random()*10,rainbow:35+random()*50,meteor:15+random()*30,asteroid:65+random()*75};
 const ranges={flight:[35,70,22],rainbow:[75,145,32],meteor:[30,70,9],asteroid:[90,180,14]};
 function trigger(kind){if(!ranges[kind]||active.some(e=>e.kind===kind))return false;if((kind==='rainbow'&&night)||(['meteor','asteroid'].includes(kind)&&!night))return false;active.push({kind,age:0,duration:ranges[kind][2],seed:random(),id:time+random()});return true;}
 return{active,trigger,setNight(v){night=v;for(let i=active.length-1;i>=0;i--)if((active[i].kind==='rainbow'&&night)||(['meteor','asteroid'].includes(active[i].kind)&&!night))active.splice(i,1);},update(dt){time+=dt;for(let i=active.length-1;i>=0;i--){active[i].age+=dt;if(active[i].age>=active[i].duration)active.splice(i,1);}for(const kind of Object.keys(next)){if(time>=next[kind]){trigger(kind);next[kind]=time+ranges[kind][0]+random()*(ranges[kind][1]-ranges[kind][0]);}}},get time(){return time;}};
}
export function createSky(scene){
 const group=new T.Group();group.userData.dynamic=true;scene.add(group);const schedule=createSkySchedule(),visuals=new Map();let night=false;
 const material=color=>new T.MeshBasicMaterial({color,fog:false,depthWrite:false});
 function mesh(geometry,mat,parent=group){const m=new T.Mesh(geometry,mat);m.userData.sky=true;m.renderOrder=-100;parent.add(m);return m;}
 const sun=mesh(new T.SphereGeometry(7,24,12),material(0xffe8a8));sun.position.set(-72,33,-235);
 const moon=mesh(new T.SphereGeometry(7,24,12),material(0xe2eaf3));moon.position.set(65,39,-232);
 const moonMarks=new T.Group();moon.add(moonMarks);for(const [x,y,r]of [[-2,2,1.2],[2,1,1.4],[-1,-2,.8],[3,-2,.6]]){const c=mesh(new T.SphereGeometry(r,10,6),material(0x9eaec4),moonMarks);c.position.set(x,y,6.3);}
 const stars=new T.Group();group.add(stars);let seed=4147;const rand=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
 for(let i=0;i<170;i++){const a=rand()*Math.PI*2,e=.025+rand()*.95,r=260,s=mesh(new T.OctahedronGeometry(.14+rand()*.2,0),material(i%4?0xdbecff:0xffdeb6),stars);s.position.set(Math.sin(a)*Math.cos(e)*r,Math.sin(e)*r,Math.cos(a)*Math.cos(e)*r);}
 const flightGeo=new T.CylinderGeometry(.45,.6,8,12);flightGeo.rotateX(Math.PI/2);
 function make(e,camera){const g=new T.Group();group.add(g);const forward=new T.Vector3();camera.getWorldDirection(forward);forward.y=0;forward.normalize();const right=new T.Vector3(-forward.z,0,forward.x),bearing=forward.clone().applyAxisAngle(new T.Vector3(0,1,0),(e.seed-.5)*.6);g.userData.base=bearing.multiplyScalar(205);g.userData.right=right;
  if(e.kind==='flight'){mesh(flightGeo,material(0xe7e8df),g);const nose=mesh(new T.SphereGeometry(.6,12,6),material(0xc2d9e5),g);nose.position.z=-4;const wing=mesh(new T.BoxGeometry(12,.1,1.5),material(0xd5dce4),g);wing.rotation.y=.2;const tail=mesh(new T.BoxGeometry(4,.1,1),material(0x598497),g);tail.position.z=3;const fin=mesh(new T.BoxGeometry(.15,2.2,1.3),material(0x9a4661),g);fin.position.set(0,.9,2.9);for(const side of [-1,1]){const light=mesh(new T.SphereGeometry(.32,8,4),material(side<0?0xff3650:0x55ff9c),g);light.position.set(side*5.8,0,0);}g.rotation.y=Math.atan2(-right.x,-right.z);}
  if(e.kind==='rainbow'){const colors=[0xff786a,0xffb557,0xf8eb91,0x89dcb1,0x70c8e8,0xa19bdf,0xc190da];for(let i=0;i<7;i++)mesh(new T.TorusGeometry(59-i*1.15,.53,4,80,Math.PI),material(colors[i]),g);g.rotation.y=Math.atan2(-forward.x,-forward.z);}
  if(e.kind==='meteor')for(let i=0;i<12;i++){const m=mesh(new T.ConeGeometry(.24,8+i%3,6),material(i%3?0xffe6c6:0xaedfff),g);m.rotation.z=-.85;m.userData.delay=i*.45;m.userData.start=[(rand()-.5)*100,25+rand()*25,0];}
  if(e.kind==='asteroid'){mesh(new T.IcosahedronGeometry(2.1,1),material(0x8b7a73),g);const tail=mesh(new T.ConeGeometry(.8,19,8),material(0xffb76f),g);tail.position.set(-8,5,0);tail.rotation.z=-2.13;}
  visuals.set(e.id,g);scene.userData.dynamicRevision=(scene.userData.dynamicRevision??0)+1;return g;
 }
 function setNight(v){night=v;sun.visible=!v;moon.visible=v;stars.visible=v;schedule.setNight(v);}
 function update(dt,camera){schedule.update(dt);group.position.copy(camera.position);for(const [id,g]of visuals)if(!schedule.active.some(e=>e.id===id)){group.remove(g);g.traverse(m=>{if(m.isMesh){if(m.geometry!==flightGeo)m.geometry.dispose();m.material.dispose();}});visuals.delete(id);scene.userData.dynamicRevision=(scene.userData.dynamicRevision??0)+1;}
  for(const e of schedule.active){const g=visuals.get(e.id)??make(e,camera),base=g.userData.base,right=g.userData.right,t=e.age/e.duration;g.position.copy(base);g.position.y=38;
   if(e.kind==='flight'){g.position.addScaledVector(right,(t-.5)*200);g.position.y=36+Math.sin(t*Math.PI)*8;}
   if(e.kind==='rainbow'){g.position.y=0;g.scale.setScalar(1);}
   if(e.kind==='meteor'){g.position.y=10;g.rotation.y=Math.atan2(-base.x,-base.z);for(const m of g.children){const age=e.age-m.userData.delay;m.visible=age>=0&&age<3;if(m.visible)m.position.set(m.userData.start[0]+age*20,m.userData.start[1]-age*17,0);}}
   if(e.kind==='asteroid'){g.position.addScaledVector(right,(t-.5)*150);g.position.y=42-t*13;g.rotation.z=t*2;}
  }
 }
 setNight(false);return{setNight,update,schedule,get active(){return schedule.active.map(e=>e.kind);}};
}
