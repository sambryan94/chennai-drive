// Original generative ambient composition and city sound design. No sampled songs or recordings.
export function createSoundscape(ctx,destination,noiseBuffer){
 const musicBus=ctx.createGain(),cityBus=ctx.createGain();musicBus.gain.value=cityBus.gain.value=0;
 const musicFilter=ctx.createBiquadFilter();musicFilter.type='lowpass';musicFilter.frequency.value=1800;musicBus.connect(musicFilter);musicFilter.connect(destination);cityBus.connect(destination);
 const reverb=ctx.createConvolver(),impulse=ctx.createBuffer(2,ctx.sampleRate*1.8,ctx.sampleRate);let seed=812;
 for(let ch=0;ch<2;ch++){const data=impulse.getChannelData(ch);for(let i=0;i<data.length;i++){seed=(seed*1664525+1013904223)>>>0;data[i]=(seed/4294967296*2-1)*Math.exp(-i/(ctx.sampleRate*.32))*.22;}}
 reverb.buffer=impulse;const wet=ctx.createGain();wet.gain.value=.24;musicFilter.connect(reverb);reverb.connect(wet);wet.connect(destination);
 let enabledMusic=true,enabledCity=true,volume=.35,paused=true,nextNote=0,beat=0,nextCity=0;const voices=new Set();
 const set=(p,v,t,k=.12)=>p.setTargetAtTime(v,t,k);
 function voice(freq,time,duration,gain,bus,type='sine'){
  if(voices.size>=32)return;const oscillator=ctx.createOscillator(),envelope=ctx.createGain();oscillator.type=type;oscillator.frequency.value=freq;envelope.gain.setValueAtTime(.0001,time);envelope.gain.exponentialRampToValueAtTime(Math.max(.0002,gain),time+.07);envelope.gain.exponentialRampToValueAtTime(.0001,time+duration);oscillator.connect(envelope);envelope.connect(bus);voices.add(oscillator);
  oscillator.onended=()=>{voices.delete(oscillator);oscillator.disconnect();envelope.disconnect();};oscillator.start(time);oscillator.stop(time+duration+.03);
 }
 const noise=ctx.createBufferSource();noise.buffer=noiseBuffer;noise.loop=true;
 const streetFilter=ctx.createBiquadFilter();streetFilter.type='lowpass';streetFilter.frequency.value=260;
 const street=ctx.createGain();street.gain.value=0;noise.connect(streetFilter);streetFilter.connect(street);street.connect(cityBus);
 const chatterFilter=ctx.createBiquadFilter();chatterFilter.type='bandpass';chatterFilter.frequency.value=720;chatterFilter.Q.value=.6;
 const chatter=ctx.createGain();chatter.gain.value=0;noise.connect(chatterFilter);chatterFilter.connect(chatter);chatter.connect(cityBus);noise.start();
 const passby=ctx.createOscillator();passby.type='triangle';passby.frequency.value=65;const passGain=ctx.createGain();passGain.gain.value=0;passby.connect(passGain);passGain.connect(cityBus);passby.start();
 function update({paused:stopped,nearby=0,closest=Infinity,shopDistance=Infinity}){
  paused=stopped;const now=ctx.currentTime;set(musicBus.gain,!paused&&enabledMusic?volume*.72:0,now);set(cityBus.gain,!paused&&enabledCity?volume:0,now);
  if(!paused&&enabledMusic){
   if(nextNote<now)nextNote=now+.04;
   // 68 BPM; Cmaj7 → Am7 → Fmaj7 → G6, with sparse pentatonic bell notes.
   if(nextNote<now+.22){const chords=[[48,55,59,64],[45,52,55,60],[41,48,52,57],[43,50,55,59]],chord=chords[Math.floor(beat/8)%4],step=beat%8,freq=m=>440*Math.pow(2,(m-69)/12);
    if(step===0)for(const note of chord)voice(freq(note),nextNote,3.4,.045,musicBus);
    const note=chord[[0,2,1,3,2,1,3,2][step]]+12;voice(freq(note),nextNote,1.9,.038,musicBus);voice(freq(note)*2,nextNote,1.2,.006,musicBus);
    if(step===6)voice(freq(chord[3]+24),nextNote,2.6,.012,musicBus);
    nextNote+=60/68/2;beat++;
   }
  }else nextNote=now+.05;
  const proximity=Math.max(0,1-closest/100),shops=Math.max(0,1-shopDistance/90);
  set(street.gain,.045+Math.min(nearby,5)*.014,now,.4);set(chatter.gain,shops*(.027+Math.sin(now*1.6)**2*.012),now,.2);set(chatterFilter.frequency,600+Math.sin(now*.71)*140,now,.3);
  set(passGain.gain,proximity*.018,now,.3);set(passby.frequency,65+proximity*35+Math.sin(now*.4)*3,now,.3);
  if(!paused&&enabledCity&&now>nextCity){nextCity=now+9+(beat%5);
   if(nearby>0){voice(330,now,.32,.019,cityBus,'triangle');voice(415,now+.025,.29,.011,cityBus,'sine');}
   else if(shops>.1){voice(1100,now,.45,.015*shops,cityBus);voice(1650,now+.12,.55,.008*shops,cityBus);}
  }
 }
 return{update,setMusic(v){enabledMusic=v;},setCity(v){enabledCity=v;},setVolume(v){volume=v;},get activeVoices(){return voices.size;}};
}
