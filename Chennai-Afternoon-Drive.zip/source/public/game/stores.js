import {fromGeo} from './roads.js';
// Mall tenants checked against official listings; street geocodes from OSM, 14 September 2026.
// Street locations are OSM points. Facade sizes/setbacks are gameplay approximations.
export const STORE_DATA = [
 {name:'POORVIKA',area:'Velachery Main Road',geo:[12.9720985,80.2191648],osmId:'way/929083568',w:23,d:14,h:9,color:0xba6841},
 {name:'BATA',area:'Velachery Main Road',geo:[12.9744602,80.2206389],osmId:'node/13638977920',w:20,d:14,h:7,color:0xab5347},
 {name:'THE CHENNAI SILKS',area:'Velachery Main Road',geo:[12.9699385,80.219036],osmId:'node/8697656183',w:32,d:20,h:16,color:0xb4985f},
 {name:'RELIANCE DIGITAL',area:'Velachery Main Road',geo:[12.9716089,80.2195973],osmId:'node/8616601057',w:28,d:16,h:12,color:0x596e9c},
 {name:'CROMA',area:'Inside Phoenix Marketcity',address:'142, first floor, Phoenix Marketcity',source:'https://store.croma.com/location/tamil-nadu/chennai/velachery',mall:true},
 {name:'RELIANCE DIGITAL',area:'Inside Phoenix Marketcity',address:'LG36, Phoenix Marketcity, Velachery Road',source:'https://www.reliancedigitalstores.in/?search=Velachery+Main+Road%2C+Chennai%2C+600042',mall:true},
 {name:'BATA',area:'Inside Phoenix Marketcity',address:'14, first floor, Phoenix Marketcity',source:'https://stores.bata.com/bata-shoes-sandals-store-in-velachery-main-road-velachery-chennai',mall:true},
 {name:'LENSKART',area:'Inside Phoenix Marketcity',address:'142, first floor, Phoenix Marketcity',source:'https://www.lenskart.com/stores/optometrist-sunglasses-velachery-road-chennai-60895/home',mall:true},
 {name:'TANISHQ',area:'Inside Phoenix Marketcity',address:'UG5, 142, Phoenix Marketcity',source:'https://stores.tanishq.co.in/store-locator/jewellery-stores/TamilNadu/Chennai/Velachery-VEL',mall:true},
 {name:'SATHYA',area:'Inside Phoenix Marketcity',address:'Phoenix Marketcity, 142 Velachery Main Road',source:'https://www.phoenixmarketcity.com/chennai/brand/Sathya/2743',mall:true},
].map(s=>{if(!s.geo)return s;const p=fromGeo(...s.geo);return{...s,anchor:[p.x,p.z],source:'https://www.openstreetmap.org/'+s.osmId};});
