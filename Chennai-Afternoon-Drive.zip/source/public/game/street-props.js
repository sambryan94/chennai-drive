import * as T from './vendor/three.module.js';
import * as C from './vendor/cannon-es.js';
// Sweep the pole centre through the SUV footprint, including this physics step.
export function sweptFootprint(x,z,dx,dz){let lo=0,hi=1;for(const [p,v,h]of [[x,dx,1.03],[z,dz,2.18]]){if(Math.abs(v)<1e-8){if(Math.abs(p)>h)return false;}else{const a=(-h-p)/v,b=(h-p)/v;lo=Math.max(lo,Math.min(a,b));hi=Math.min(hi,Math.max(a,b));if(lo>hi)return false;}}return true;}
export function createStreetProps(scene,physics,posts,onImpact=()=>{}){
 const geo=new T.BoxGeometry(1,1,1),metal=new T.MeshStandardMaterial({color:0x626d7b,roughness:.65}),bulb=new T.MeshBasicMaterial({color:0xffcc9b}),items=[];
 for(const data of posts){const group=new T.Group();group.userData.dynamic=true;const part=(x,y,z,w,h,d,mat)=>{const m=new T.Mesh(geo,mat);m.position.set(x,y,z);m.scale.set(w,h,d);group.add(m);return m;};
  part(0,0,0,.18,9.2,.18,metal);part(-data.side,4.5,0,2.2,.15,.18,metal);const lamp=part(-data.side*1.9,4.4,0,.8,.16,.4,bulb);scene.add(group);
  const body=new C.Body({type:C.Body.STATIC,mass:0,shape:new C.Box(new C.Vec3(.13,4.6,.13)),position:new C.Vec3(data.x,4.6,data.z),collisionFilterGroup:2,collisionFilterMask:7,linearDamping:.25,angularDamping:.3,allowSleep:true,sleepSpeedLimit:.2,sleepTimeLimit:1});body.quaternion.setFromEuler(0,data.angle,0);body.propType='lamp';group.position.copy(body.position);group.quaternion.copy(body.quaternion);
  items.push({...data,group,body,lamp,fallen:false});
 }
 let impacts=0;const point=new C.Vec3(),local=new C.Vec3(),velocity=new C.Vec3();
 function beforeStep(dt,player){for(const p of items){const distance=Math.hypot(p.x-player.position.x,p.z-player.position.z);if(distance<75){if(!p.body.world)physics.world.addBody(p.body);}else if(p.body.world&&(p.body.type===C.Body.STATIC||p.body.sleepState===C.Body.SLEEPING)){physics.world.removeBody(p.body);}
   if(p.fallen||distance>5||player.velocity.length()<1.5)continue;point.set(p.x,player.position.y,p.z);player.pointToLocalFrame(point,local);player.vectorToLocalFrame(player.velocity,velocity);
   if(sweptFootprint(local.x,local.z,-velocity.x*dt,-velocity.z*dt)){
    p.fallen=true;impacts++;p.body.type=C.Body.DYNAMIC;p.body.mass=95;p.body.updateMassProperties();p.body.updateSolveMassProperties();p.body.wakeUp();p.body.aabbNeedsUpdate=true;
    const speed=Math.hypot(player.velocity.x,player.velocity.z),fx=player.velocity.x/speed,fz=player.velocity.z/speed;
    p.body.angularVelocity.set(fz*1.7,0,-fx*1.7);p.body.velocity.set(fx*1.4,.1,fz*1.4);player.velocity.scale(.72,player.velocity);p.lamp.visible=false;onImpact('lamp');
   }
 }}
 function sync(player){for(const p of items){p.group.position.copy(p.body.position);p.group.quaternion.copy(p.body.quaternion);p.group.visible=Math.hypot(p.body.position.x-player.position.x,p.body.position.z-player.position.z)<180;}}
 return{items,beforeStep,sync,isBlocked(x,z){return items.some(p=>p.fallen&&Math.hypot(p.body.position.x-x,p.body.position.z-z)<8);},get impacts(){return impacts;}};
}
