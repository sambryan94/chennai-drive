// Every finger owns its action until release/cancel, including outside the button.
export function createPointerState(onChange = () => {}) {
  const owners = new Map();
  const state = {throttle: 0, brake: 0, steer: 0, handbrake: false, boost: false};
  const update = () => {
    const actions = new Set(owners.values());
    Object.assign(state, {throttle: +actions.has('throttle'), brake: +actions.has('brake'), steer: +actions.has('left') - +actions.has('right'), handbrake: actions.has('handbrake'), boost: actions.has('boost')});
    onChange(state, actions);
  };
  return {state, press(id, action) {owners.set(id, action); update();}, release(id) {owners.delete(id); update();}, clear() {owners.clear(); update();}};
}

export function bindTouchControls(root, canDrive) {
  const buttons = [...root.querySelectorAll('[data-drive]')];
  const controls = createPointerState((_, actions) => {
    for (const button of buttons) button.setAttribute('aria-pressed', String(actions.has(button.dataset.drive)));
  });
  const stopDefault = event => {if (event.cancelable) event.preventDefault();};
  for (const button of buttons) {
    button.type = 'button'; button.draggable = false;
    button.setAttribute('aria-pressed', 'false');
    for (const event of ['contextmenu', 'selectstart', 'dragstart']) button.addEventListener(event, stopDefault);
    button.addEventListener('pointerdown', event => {
      stopDefault(event);
      if (!canDrive() || (event.pointerType === 'mouse' && event.button !== 0)) return;
      controls.press(event.pointerId, button.dataset.drive);
      try {button.setPointerCapture(event.pointerId);} catch { /* Global release is a fallback. */ }
    });
    button.addEventListener('lostpointercapture', event => controls.release(event.pointerId));
    // Safari long-press prevention complements Pointer Events; it doesn't own input.
    button.addEventListener('touchstart', stopDefault, {passive: false});
    button.addEventListener('touchmove', stopDefault, {passive: false});
  }
  for (const event of ['pointerup', 'pointercancel']) window.addEventListener(event, e => controls.release(e.pointerId), {capture: true});
  window.addEventListener('blur', () => controls.clear());
  document.addEventListener('visibilitychange', () => {if (document.hidden) controls.clear();});
  return controls;
}
