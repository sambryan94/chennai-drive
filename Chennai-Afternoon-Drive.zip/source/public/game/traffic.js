import {roundedBox} from './geometry.js';
import * as T from './vendor/three.module.js';
import * as C from './vendor/cannon-es.js';

export const TRAFFIC_COUNT = 42; // Fixed pool: 35 cars and seven buses.
export {sampleLane,prepareTrafficRoutes} from './route-utils.js';
import {sampleLane,prepareTrafficRoutes} from './route-utils.js';
export function createTraffic(scene,physics,world,signals=null){
 const routes=prepareTrafficRoutes(world.roads),trafficRouteIndices=routes.map((r,i)=>!r.interior&&r.length>300?i:-1).filter(i=>i>=0),items=[],boxGeometry=roundedBox(1,1,1,.12),wheelGeometry=new T.CylinderGeometry(.36,.36,.24,24);wheelGeometry.rotateZ(Math.PI/2);
 const materials=new Map();const material=color=>{if(!materials.has(color))materials.set(color,new T.MeshStandardMaterial({color,roughness:.8,emissive:[0xf1e5b8,0xab3b32].includes(color)?color:0,emissiveIntensity:.8}));return materials.get(color);};
 function model(bus,color){const group=new T.Group();group.userData.dynamic=true;const wheels=[];
  const part=(w,h,d,x,y,z,col)=>{const m=new T.Mesh(boxGeometry,material(col));m.scale.set(w,h,d);m.position.set(x,y,z);m.castShadow=true;group.add(m);return m;};
  const width=bus?2.45:1.8,length=bus?9.2:4.3;
  part(width,bus?2.3:.72,length,0,bus?1.55:.78,0,color);
  if(bus){part(2.3,.8,.04,0,2.02,-4.62,0x284852);part(2.5,.66,7.6,0,2.07,.3,0x35535a);part(2.5,.18,9.15,0,.9,0,0xe5d7ad);part(2.43,.1,9.2,0,2.75,0,0xdfd9be);for(const z of [-3,-1.5,0,1.5,3])part(2.51,.76,.09,0,2.07,z,color);}
  else{part(1.52,.7,2.35,0,1.35,.3,0x35535a);part(1.56,.1,2.4,0,1.73,.3,color);part(.1,.72,2.35,0,1.35,.3,color);}
  for(const x of [-1,1]){if(!bus){part(.15,.05,2.15,x*.78,.95,.35,0xb9c6c5);part(.24,.16,.22,x*.96,1.35,-.7,color);part(.055,.68,.12,x*.77,1.35,.45,color);}part(.36,.13,.07,x*width*.32,bus?.7:.74,-length/2-.04,0xf1e5b8);part(.36,.15,.07,x*width*.32,bus?.7:.77,length/2+.04,0xab3b32);
   for(const z of [-length*.31,length*.31]){const m=new T.Mesh(wheelGeometry,material(0x213034));if(bus)m.scale.set(1.27,1.27,1.27);m.position.set(x*width*.49,bus?.46:.36,z);group.add(m);wheels.push(m);}}
  scene.add(group);return{group,wheels,width,length};
 }
 for(let i=0;i<TRAFFIC_COUNT;i++){
  const bus=i%6===0,routeIndex=trafficRouteIndices[i%trafficRouteIndices.length],route=routes[routeIndex],direction=route.oneway||(Math.floor(i/trafficRouteIndices.length)%2===0?1:-1);
  // Different phases spread each direction through the route, including around the start.
  const distance=route.length*(i===0?.205:i===12?.215:((i*.173+.11)%1)),pose=sampleLane(route,distance,direction),visual=model(bus,bus?(i%2?0xc48359:0x738d70):[0xd8c8a9,0x747f96,0xb87857,0x8bada8,0xe0dfca][i%5]);
  const body=new C.Body({type:C.Body.DYNAMIC,mass:bus?8500:1250,material:physics.carMaterial,linearDamping:.2,angularDamping:.65,linearFactor:new C.Vec3(1,0,1),angularFactor:new C.Vec3(0,1,0),collisionFilterGroup:4,collisionFilterMask:7,shape:new C.Box(new C.Vec3(visual.width/2,bus?1.3:.7,visual.length/2))});
  body.position.set(pose.x,bus?1.45:.94,pose.z);body.quaternion.setFromEuler(0,pose.heading,0);body.aabbNeedsUpdate=true;
  body.propType='traffic';body.trafficId=i;
  items.push({crashed:false,angry:0,impactSpeed:0,id:i,bus,routeIndex,direction,distance,speed:bus?7.5:9.5+(i%3),cruise:bus?7.5:9.5+(i%3),pose,body,...visual,braking:false});
 }
 const crossings=signals?.junctions??[];let nearby=0,closest=Infinity,impacts=0;
 for(const item of items)item.body.addEventListener('collide',e=>{const speed=Math.abs(e.contact.getImpactVelocityAlongNormal());if(speed<2.2||item.crashed)return;item.crashed=true;item.angry=5;item.impactSpeed=speed;item.speed=0;impacts++;});
 function setPose(item,pose){item.pose=pose;item.group.position.set(pose.x,0,pose.z);item.group.rotation.y=pose.heading;}
 function clearAround(x,z,radius=25){for(const item of items)if(Math.hypot(item.pose.x-x,item.pose.z-z)<radius){item.crashed=false;item.angry=0;item.body.angularVelocity.setZero();const route=routes[item.routeIndex];item.distance=(item.distance+180)%route.length;setPose(item,sampleLane(route,item.distance,item.direction));item.body.position.set(item.pose.x,item.bus?1.45:.94,item.pose.z);item.body.velocity.setZero();item.body.quaternion.setFromEuler(0,item.pose.heading,0);item.body.aabbNeedsUpdate=true;}}
 function update(dt,player,pedestrians=[]){
 nearby=0;closest=Infinity;
  const snapshots=items.map(item=>({x:item.pose.x,z:item.pose.z,length:item.length,id:item.id}));
  for(const item of items){const route=routes[item.routeIndex],pose=item.pose,dist=Math.hypot(pose.x-player.position.x,pose.z-player.position.z);let target=item.cruise;item.angry=Math.max(0,item.angry-dt);
   if(item.crashed){const b=item.body;item.pose={...pose,x:b.position.x,z:b.position.z};item.group.position.set(b.position.x,0,b.position.z);item.group.quaternion.copy(b.quaternion);item.group.visible=dist<320;if(dist<100){nearby++;closest=Math.min(closest,dist);}if(dist>160&&item.angry===0){item.crashed=false;item.distance=(item.distance+120)%route.length;const safe=sampleLane(route,item.distance,item.direction);setPose(item,safe);b.position.set(safe.x,item.bus?1.45:.94,safe.z);b.quaternion.setFromEuler(0,safe.heading,0);b.velocity.setZero();b.angularVelocity.setZero();b.aabbNeedsUpdate=true;}continue;}

   const obstacles=[...snapshots,...pedestrians,{x:player.position.x,z:player.position.z,length:4.3,id:-1}];
   for(const other of obstacles){if(other.id===item.id)continue;const dx=other.x-pose.x,dz=other.z-pose.z,ahead=dx*pose.fx+dz*pose.fz,lateral=Math.abs(dx*pose.fz-dz*pose.fx);
    if(ahead>0&&lateral<2.8){const clearance=ahead-(item.length+other.length)/2;target=Math.min(target,Math.max(0,(clearance-5)*.7));}
   }
   if(signals)target=Math.min(target,signals.speedLimit(item));
   const change=Math.max(-5*dt,Math.min(1.7*dt,target-item.speed));item.speed=Math.max(0,item.speed+change);item.braking=change<-.01;
   item.distance+=item.speed*dt*item.direction;
   if(item.distance<12||item.distance>route.length-12){
    if(dist>210){if(route.oneway)item.distance=route.oneway===1?14:route.length-14;else{item.direction*=-1;item.distance=Math.max(14,Math.min(route.length-14,item.distance));}}
    else{item.distance=Math.max(12,Math.min(route.length-12,item.distance));item.speed=0;}
   }
   const next=sampleLane(route,item.distance,item.direction);setPose(item,next);
   // Fixed-step kinematic colliders match the moving visible traffic, only in the player's vicinity.
   const close=dist<190;item.group.visible=dist<320;
   if(close){if(!item.body.world){item.body.position.set(next.x,item.bus?1.45:.94,next.z);physics.world.addBody(item.body);}
    item.body.velocity.set((next.x-item.body.position.x)/dt,0,(next.z-item.body.position.z)/dt);item.body.quaternion.setFromEuler(0,next.heading,0);item.body.aabbNeedsUpdate=true;
   }else if(item.body.world){physics.world.removeBody(item.body);item.body.velocity.setZero();}
   item.body.angularVelocity.setZero();for(const wheel of item.wheels)wheel.rotation.x-=item.speed*dt/(item.bus?.46:.36);
   if(dist<100){nearby++;closest=Math.min(closest,dist);}
  }
 }
 for(const item of items)setPose(item,item.pose);
 return{items,update,clearAround,get impacts(){return impacts;},get nearby(){return nearby;},get closest(){return closest;},crossings};
}
