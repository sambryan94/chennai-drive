// Six-speed torque-converter automatic inspired by the original Taigun 1.0 TSI AT.
// Ratios, shift schedule and converter slip are gameplay approximations, not VW data.
export const TRANSMISSION = Object.freeze({
  ratios: [3.60, 2.25, 1.55, 1.18, .93, .76], finalDrive: 3.65,
  idleRPM: 820, redlineRPM: 6000, shiftSeconds: .28, shiftCooldown: 1.2,
  wheelRadius: .335, peakTorque: 178, efficiency: .88,
});

export function createTransmission() {
  const state = { gearNumber: 1, rpm: 820, shifting: false, shiftCount: 0, load: 0, driveForce: 0 };
  let shiftRemaining = 0, cooldown = 0, previousMode = 'D';
  function reset() {
    Object.assign(state, {gearNumber: 1, rpm: 820, shifting: false, shiftCount: 0, load: 0, driveForce: 0});
    shiftRemaining = cooldown = 0; previousMode = 'D';
  }
  function update(dt, speed, throttle, mode = 'D', braking = false, boost = false) {
    const cfg = TRANSMISSION;
    cooldown = Math.max(0, cooldown - dt);
    shiftRemaining = Math.max(0, shiftRemaining - dt);
    if (mode !== previousMode) {state.gearNumber = 1; shiftRemaining = 0; cooldown = .6; previousMode = mode;}
    const wheelRPM = Math.abs(speed) * 60 / (2 * Math.PI * cfg.wheelRadius);
    const coupledRPM = ratio => wheelRPM * ratio * cfg.finalDrive;
    const demand = braking ? 0 : Math.max(0, Math.min(1, throttle));
    if (mode === 'D' && shiftRemaining === 0) {
      const g = state.gearNumber, rpm = coupledRPM(cfg.ratios[g - 1]);
      let next = g;
      const upAt = (boost ? 3200 : 2150) + demand * 650;
      if (Math.abs(speed) < 1.2) next = 1;
      else if (cooldown === 0) {
        if (g < 6 && rpm > upAt) next++;
        else if (g > 1 && (rpm < 1200 || (demand > .82 && rpm < 1600)) && coupledRPM(cfg.ratios[g - 2]) < upAt - 350) next--;
      }
      if (next !== g) {state.gearNumber = next; state.shiftCount++; shiftRemaining = cfg.shiftSeconds; cooldown = cfg.shiftCooldown;}
    }
    state.shifting = shiftRemaining > 0;
    const ratio = mode === 'R' ? 3.1 : cfg.ratios[state.gearNumber - 1];
    // Converter slips on launch and progressively locks as road speed rises.
    const slip = demand * (80 + 850 * Math.exp(-Math.abs(speed) / 4));
    const targetRPM = Math.min(cfg.redlineRPM, Math.max(cfg.idleRPM, coupledRPM(ratio) + slip));
    state.rpm += (targetRPM - state.rpm) * (1 - Math.exp(-dt * (state.shifting ? 14 : 8)));
    state.load += ((state.shifting ? demand * .14 : demand) - state.load) * (1 - Math.exp(-dt * 10));
    // Broad small turbo-petrol torque plateau; force is divided between two driven wheels.
    const torqueFraction = state.rpm < 1750 ? .67 + .33 * Math.max(0, state.rpm - 820) / 930 : state.rpm > 4500 ? Math.max(.55, 1 - (state.rpm - 4500) / 3300) : 1;
    state.driveForce = cfg.peakTorque * torqueFraction * ratio * cfg.finalDrive * cfg.efficiency / (2 * cfg.wheelRadius) * (state.shifting ? .22 : 1);
    return state;
  }
  return {state, update, reset};
}
