import * as C from './vendor/cannon-es.js';
import {createBoost} from './boost.js';
import {createTransmission} from './transmission.js';
export const TUNING = Object.freeze({mass:1320,wheelbase:2.55,track:1.52,wheelRadius:.335,wheelWidth:.215,suspensionRest:.34,suspensionStiffness:32,dampingCompression:4.4,dampingRelaxation:4.8,maxSuspensionTravel:.19,frictionSlip:3.4,engineForce:2250,brakeImpulse:42,handbrakeImpulse:68,maxSpeed:120/3.6,turboSpeed:180/3.6,turboMultiplier:3,maxReverse:5.6,airDrag:.40,rollingResistance:95});
export function createPhysics(){
 const world=new C.World({gravity:new C.Vec3(0,-9.81,0)});
 world.broadphase=new C.SAPBroadphase(world);world.solver.iterations=12;world.allowSleep=true;
 world.defaultContactMaterial.friction=.25;world.defaultContactMaterial.restitution=.015;
 const ground=new C.Body({mass:0,shape:new C.Plane()});ground.quaternion.setFromEuler(-Math.PI/2,0,0);ground.position.y=-.08;ground.aabbNeedsUpdate=true;world.addBody(ground);
 const carMaterial=new C.Material('vehicle'), obstacleMaterial=new C.Material('solid'),treeMaterial=new C.Material('tree');
 world.addContactMaterial(new C.ContactMaterial(carMaterial,obstacleMaterial,{friction:.32,restitution:.24}));
 world.addContactMaterial(new C.ContactMaterial(carMaterial,carMaterial,{friction:.28,restitution:.22}));
 const chassis=new C.Body({mass:TUNING.mass,material:carMaterial,angularDamping:.65,linearDamping:.003,allowSleep:false});
 chassis.addShape(new C.Box(new C.Vec3(.85,.29,1.99)),new C.Vec3(0,.05,0));
 const vehicle=new C.RaycastVehicle({chassisBody:chassis,indexRightAxis:0,indexUpAxis:1,indexForwardAxis:2});
 for(const z of [-TUNING.wheelbase/2,TUNING.wheelbase/2])for(const x of [-TUNING.track/2,TUNING.track/2])vehicle.addWheel({
  radius:TUNING.wheelRadius,directionLocal:new C.Vec3(0,-1,0),axleLocal:new C.Vec3(-1,0,0),
  chassisConnectionPointLocal:new C.Vec3(x,0,z),suspensionRestLength:TUNING.suspensionRest,suspensionStiffness:TUNING.suspensionStiffness,
  dampingRelaxation:TUNING.dampingRelaxation,dampingCompression:TUNING.dampingCompression,frictionSlip:TUNING.frictionSlip,
  rollInfluence:.045,maxSuspensionForce:45000,maxSuspensionTravel:TUNING.maxSuspensionTravel,customSlidingRotationalSpeed:-25,useCustomSlidingRotationalSpeed:true
 });
 vehicle.addToWorld(world);
 const transmission=createTransmission(),boost=createBoost();
 const state={rpm:820,gearNumber:1,shifting:false,shiftCount:0,load:0,boost:false,boostRemaining:8,boostLocked:false,speed:0,steering:0,throttle:0,gear:'D',braking:false,offroad:false,contacts:0,reverseDelay:0};
 function reset(x,z,heading=0){chassis.position.set(x,1.15,z);chassis.quaternion.setFromEuler(0,heading,0);chassis.velocity.setZero();chassis.angularVelocity.setZero();chassis.force.setZero();chassis.torque.setZero();chassis.previousPosition.copy(chassis.position);chassis.interpolatedPosition.copy(chassis.position);chassis.previousQuaternion.copy(chassis.quaternion);chassis.interpolatedQuaternion.copy(chassis.quaternion);chassis.aabbNeedsUpdate=true;world.broadphase.dirty=true;state.speed=0;state.steering=0;state.throttle=0;state.reverseDelay=0;state.gear='D';state.boost=false;transmission.reset();Object.assign(state,transmission.state);for(let i=0;i<4;i++){vehicle.setBrake(0,i);vehicle.applyEngineForce(0,i);vehicle.wheelInfos[i].rotation=0;}chassis.wakeUp();collisionTick=0;}
 const obstacles=[];let collisionTick=0;
 function updateCollisionArea(x,z){for(const b of obstacles){const near=Math.abs(b.position.x-x)<170+b.boundingRadius&&Math.abs(b.position.z-z)<170+b.boundingRadius;if(near&&!b.world)world.addBody(b);else if(!near&&b.world)world.removeBody(b);}}
 const forward=new C.Vec3(),drag=new C.Vec3();
 function step(dt,input,offroad=false,advanceBoost=true){
  if(collisionTick++%30===0)updateCollisionArea(chassis.position.x,chassis.position.z);
  chassis.vectorToWorldFrame(new C.Vec3(0,0,-1),forward);state.speed=chassis.velocity.dot(forward);state.offroad=offroad;
  const k=1-Math.exp(-5*dt);state.throttle+=(input.throttle-state.throttle)*k;
  const steerLimit=Math.min(.48/(1+Math.abs(state.speed)*.04),Math.atan(8*TUNING.wheelbase/Math.max(1,state.speed*state.speed)));
  state.steering+=((input.steer||0)*steerLimit-state.steering)*(1-Math.exp(-8*dt));
  vehicle.setSteeringValue(state.steering,0);vehicle.setSteeringValue(state.steering,1);
  let force=0,brake=0;state.braking=false;if(advanceBoost)Object.assign(state,boost.update(dt,!!input.boost,input.throttle>.05&&input.brake<.05&&!input.handbrake&&!offroad&&state.speed>-.45));else state.boost=false;
  const speedLimit=state.boost?TUNING.turboSpeed:TUNING.maxSpeed;
  if(input.brake>.05){
   if(state.speed>.45){brake=TUNING.brakeImpulse*input.brake;state.reverseDelay=0;state.braking=true;}
   else {state.reverseDelay+=dt;if(state.reverseDelay>.32){state.gear='R';force=-TUNING.engineForce*.62*input.brake*(state.speed>-TUNING.maxReverse?1:0);}else brake=TUNING.brakeImpulse;}
  }else {state.reverseDelay=0;if(input.throttle>.05){if(state.speed<-.45){brake=TUNING.brakeImpulse;state.braking=true;}else{state.gear='D';force=TUNING.engineForce*state.throttle*Math.max(0,Math.min(1,(speedLimit-Math.max(0,state.speed))*12));}}}
  const drivetrain=transmission.update(dt,state.speed,state.gear==='R'?input.brake:state.throttle,state.gear,state.braking||input.handbrake,state.boost);
  Object.assign(state,drivetrain);
  if(state.gear==='D')force*=Math.min(1,drivetrain.driveForce/TUNING.engineForce)*(state.boost?TUNING.turboMultiplier:1);
  // Physical road load instead of the old heavy velocity damping that capped speed at 66 km/h.
  const velocity=chassis.velocity,horizontal=Math.hypot(velocity.x,velocity.z);
  if(horizontal>.05){const resistance=TUNING.rollingResistance+TUNING.airDrag*horizontal*horizontal;drag.set(-velocity.x/horizontal*resistance,0,-velocity.z/horizontal*resistance);chassis.applyForce(drag);}
  if(state.speed>speedLimit+.1)brake=Math.max(brake,Math.min(8,(state.speed-speedLimit)*.9));
  if(offroad){force*=.55;brake=Math.max(brake,Math.abs(state.speed)>8?4:0);}
  if(input.handbrake){brake=Math.max(brake,10);force=0;state.braking=true;}
  for(let i=0;i<4;i++){vehicle.applyEngineForce(i<2?force:0,i);vehicle.setBrake(i>=2&&input.handbrake?TUNING.handbrakeImpulse:brake,i);vehicle.wheelInfos[i].frictionSlip=offroad?2:TUNING.frictionSlip;}
  // Anti-roll torque keeps a light road SUV predictable without locking its body axes.
  const up=new C.Vec3();chassis.vectorToWorldFrame(new C.Vec3(0,1,0),up);
  if(up.y>.2){chassis.torque.x-=up.z*2200+chassis.angularVelocity.x*450;chassis.torque.z+=up.x*2200-chassis.angularVelocity.z*450;}
  world.step(dt);state.contacts=vehicle.wheelInfos.filter(w=>w.isInContact).length;
  chassis.vectorToWorldFrame(new C.Vec3(0,0,-1),forward);state.speed=chassis.velocity.dot(forward);
 }
 function box(x,z,w,d,h,y=0,angle=0){const b=new C.Body({mass:0,material:obstacleMaterial,collisionFilterGroup:2,shape:new C.Box(new C.Vec3(w/2,h/2,d/2)),position:new C.Vec3(x,y+h/2,z)});b.quaternion.setFromEuler(0,angle,0);b.aabbNeedsUpdate=true;obstacles.push(b);return b;}
 function roadCollision(vertices,indices){const b=new C.Body({mass:0,shape:new C.Trimesh(vertices,indices)});b.propType='road';world.addBody(b);return b;}
 reset(525,900);
 return{world,chassis,vehicle,state,step,reset,box,roadCollision,carMaterial,treeMaterial};
}
