import {createMapBoundary} from './map-boundary.js';
import {roundedBox,cabinGeometry} from './geometry.js';
import {prepareTrafficRoutes,sampleLane} from './route-utils.js';
import * as T from './vendor/three.module.js';
import {STORE_DATA} from './stores.js';
import {ROAD_DATA,LANDMARKS,PLACES,MAP_BOUNDS,roadPoints,roadClearance,footprintClear,nearestOnRoad} from './roads.js';
const boxGeo=new T.BoxGeometry(1,1,1),tmp=new T.Object3D();
export function createWorld(scene,physics){
 const materials=new Map(),batches=new Map(),trees=[],lampPosts=[];
 const mat=(color)=>{if(!materials.has(color))materials.set(color,new T.MeshStandardMaterial({color,roughness:.88}));return materials.get(color);};
 function batch(type,geo,color,x,y,z,sx,sy,sz,ry=0,rz=0){let b=batches.get(type);if(!b){b={geo,mat:mat(color),items:[]};batches.set(type,b);}b.items.push([x,y,z,sx,sy,sz,ry,rz,color]);}
 function cube(x,y,z,w,h,d,color,ry=0){batch('boxes',boxGeo,0xffffff,x,y,z,w,h,d,ry,0,color);batches.get('boxes').items.at(-1)[8]=color;}
 let seed=9781;const rand=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
 const foliageGeo=new T.IcosahedronGeometry(1,1),trunkGeo=new T.CylinderGeometry(.65,1,1,10),leafGeo=new T.ConeGeometry(1,1,8);
 const roads=ROAD_DATA.map(r=>({...r,points:roadPoints(r).map(p=>new T.Vector3(p.x,.035,p.z))}));
 const boundary=createMapBoundary(scene,physics);
 const surface=new T.Mesh(new T.PlaneGeometry(9000,9000),mat(0x9ca383));surface.rotation.x=-Math.PI/2;surface.position.y=-.08;surface.receiveShadow=true;scene.add(surface);
 function ribbon(road,width,y,color,collision=false){const verts=[],indices=[];for(let i=0;i<road.points.length;i++){const p=road.points[i],a=road.points[Math.max(0,i-1)],b=road.points[Math.min(road.points.length-1,i+1)];const len=Math.hypot(b.x-a.x,b.z-a.z),nx=-(b.z-a.z)/len,nz=(b.x-a.x)/len;verts.push(p.x+nx*width/2,y,p.z+nz*width/2,p.x-nx*width/2,y,p.z-nz*width/2);if(i<road.points.length-1){const j=i*2;indices.push(j,j+2,j+1,j+1,j+2,j+3);}}
  const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(verts,3));geo.setIndex(indices);geo.computeVertexNormals();const mesh=new T.Mesh(geo,new T.MeshStandardMaterial({color,roughness:1,side:T.DoubleSide}));mesh.receiveShadow=true;scene.add(mesh);if(collision)physics.roadCollision(verts,indices);
 }
 for(const road of roads){ribbon(road,road.width+6,-.005,0xb9b5a0);ribbon(road,road.width,.045,0x5e6665,true);
  // Match paint to real segment lengths and leave intersections unmarked.
  if(!road.interior){const others=roads.filter(r=>r!==road);for(let i=1;i<road.points.length;i++){
   const a=road.points[i-1],b=road.points[i],length=Math.hypot(b.x-a.x,b.z-a.z);if(length<.1)continue;
   const x=(a.x+b.x)/2,z=(a.z+b.z)/2,angle=Math.atan2(b.x-a.x,b.z-a.z),nx=Math.cos(angle),nz=-Math.sin(angle);
   if([a,{x,z},b].some(p=>roadClearance(others,p.x,p.z)<3))continue;
   if(i%2===0&&!road.oneway)cube(x,.057,z,.14,.014,Math.min(4.3,length*.75),0xd8d9bd,angle);
   for(const side of [-1,1])cube(x+nx*(road.width/2-.45)*side,.057,z+nz*(road.width/2-.45)*side,.12,.014,length,0xd6d6be,angle);
  }}
  for(let i=1;i<road.points.length-1;i++){
   const p=road.points[i],a=road.points[i-1],b=road.points[i+1],angle=Math.atan2(b.x-a.x,b.z-a.z),nx=Math.cos(angle),nz=-Math.sin(angle);

   for(const side of [-1,1]){

    if(i%6===0 && nearestOtherRoad(road,p,roads)>20){const cx=p.x+nx*(road.width/2+1.7)*side,cz=p.z+nz*(road.width/2+1.7)*side;if(footprintClear(roads,cx,cz,.45,5.6,angle,.5)){cube(cx,.12,cz,.45,.24,5.6,i%12===0?0xd6c9a8:0x5a6256,angle);physics.box(cx,cz,.45,5.6,.24,0,angle);}}
    if(i%13===0){const x=p.x+nx*(road.width/2+5)*side,z=p.z+nz*(road.width/2+5)*side;tree(x,z,rand()>.4);}

   }
  }
 }
 // Fifty-metre stations; suppress adjacent-carriageway duplicates and junction conflicts.
 for(const [routeIndex,route]of prepareTrafficRoutes(roads).entries())for(let distance=25;distance<route.length-10;distance+=50){const p=sampleLane({...route,width:0},distance,1),angle=p.heading,nx=Math.cos(angle),nz=-Math.sin(angle);for(const side of [-1,1]){const x=p.x+nx*(route.width/2+2)*side,z=p.z+nz*(route.width/2+2)*side,n=nearestOnRoad(roads,x,z);if(roadClearance(roads,x,z)>.8&&!lampPosts.some(q=>Math.hypot(q.x-x,q.z-z)<32))lampPosts.push({x,z,angle,side,nx,nz,routeIndex,distance});}}
 function nearestOtherRoad(road,p,all){return nearestOnRoad(all.filter(r=>r!==road),p.x,p.z).distance;}
 function tree(x,z,palm=false){if(roadClearance(roads,x,z)<2)return;const h=palm?8+rand()*4:5+rand()*4;const body=physics.box(x,z,.55,.55,h);body.material=physics.treeMaterial;body.propType='tree';trees.push({x,z,h,body});batch('trunks',trunkGeo,0x786750,x,h/2,z,.23,h,.23);if(palm){for(let j=0;j<6;j++){const a=j*Math.PI/3;batch('palm',leafGeo,0x476847,x+Math.sin(a)*1.5,h,z+Math.cos(a)*1.5,1.1,4,.27,a,1.05);}}else{batch('trees',foliageGeo,0x627c48,x,h,z,3.4+rand(),3,3.4+rand());batch('trees',foliageGeo,0x627c48,x+1.3,h-1.1,z-1,2.7,2.2,2.7);}}
 const colors=[0xcbbba4,0xd7bd9e,0xc8c9b3,0xa8bab7,0xcab6ad,0xe0c8ac,0xbdc1b5,0xc5a890];
 const buildings=[];
 function building(x,z,w,d,h,color,ry=0,detail=true){
  if(!footprintClear(roads,x,z,w+1,d+1,ry,1))return false;
  cube(x,h/2,z,w,h,d,color,ry);cube(x,h+.16,z,w+.45,.32,d+.45,0xe2d5be,ry);
  const body=physics.box(x,z,w,d,h,0,ry);body.propType='building';buildings.push({x,z,w,d,h,ry,body});
  if(detail){for(let floor=0;floor<Math.min(5,Math.floor(h/3));floor++)for(let side of [-1,1])for(let j=0;j<Math.max(2,Math.floor(w/4));j++){
   const lx=-w/2+2+j*3.8,lz=side*(d/2+.03),wx=x+Math.cos(ry)*lx+Math.sin(ry)*lz,wz=z-Math.sin(ry)*lx+Math.cos(ry)*lz;
   cube(wx,2+floor*3,wz,1.4,1.4,.08,floor===0?0x456164:0x627874,ry);
   cube(wx,1.22+floor*3,wz,1.72,.13,.35,0xe3d8c4,ry);
   cube(wx,2+floor*3,wz,.065,1.4,.14,0xa6b1a6,ry);
   if(floor===1&&j%2===0){cube(wx,1.5+floor*3,wz,2,.1,1.05,0xc7baad,ry);cube(wx+Math.sin(ry)*side*.48,1.9+floor*3,wz+Math.cos(ry)*side*.48,2,.55,.07,0x637575,ry);}
  }
  if(h<15){cube(x,h+1.2,z,2.3,2,2.3,0x495659,ry);cube(x+w*.25,1.4,z+d/2+.12,w*.36,2.6,.15,0x698274,ry);}}
 }
 for(const landmark of LANDMARKS){const {x,z,w,d,h,color,name}=landmark;building(x,z,w,d,h,color);cube(x,h*.72,z+d/2+.13,w*.89,4,.2,0x274e55);sign(name,x,h*.73,z+d/2+.29,Math.min(w*.77,68),3.3);for(let i=-3;i<=3;i++){cube(x+i*w/8,h*.35,z+d/2+.15,w/10,h*.4,.2,0x5c7c80);}}
 // Named shops use original, simplified facades with readable road-facing signs.
 const storefronts=[];
 for(const shop of STORE_DATA.filter(s=>!s.mall)){
  const n=nearestOnRoad(roads,...shop.anchor),side=(shop.anchor[0]-n.x)*Math.cos(n.heading)-(shop.anchor[1]-n.z)*Math.sin(n.heading)>0?1:-1,offset=Math.max(n.distance,n.width/2+4+shop.d/2);
  const x=n.x+Math.cos(n.heading)*offset*side,z=n.z-Math.sin(n.heading)*offset*side;
  const ry=n.heading-Math.PI/2*side;
  if(!footprintClear(roads,x,z,shop.w+1,shop.d+1,ry,1))continue;
  building(x,z,shop.w,shop.d,shop.h,0xd4c7ae,ry);
  const front=(lx,lz)=>[x+Math.cos(ry)*lx+Math.sin(ry)*lz,z-Math.sin(ry)*lx+Math.cos(ry)*lz];
  const [fx,fz]=front(0,shop.d/2+.16);
  cube(fx,4.5,fz,shop.w*.94,2.5,.25,shop.color,ry);
  sign(shop.name,fx+Math.sin(ry)*.2,4.5,fz+Math.cos(ry)*.2,shop.w*.89,2,ry,shop.color);
  for(let j=-1;j<=1;j++){const q=front(j*shop.w*.24,shop.d/2+.2);cube(q[0],1.5,q[1],shop.w*.21,2.6,.16,0x395d65,ry);}
  const q=front(0,shop.d/2+1.1);cube(q[0],3.05,q[1],shop.w, .15,2.1,shop.color,ry);
  // A projecting board is also legible while approaching along the road.
  const blade=front(shop.w*.43,shop.d/2+2.5);sign(shop.name,blade[0],6.8,blade[1],9,1.4,ry+Math.PI/2,shop.color);
  storefronts.push({...shop,side,x,z,heading:n.heading,roadX:n.x,roadZ:n.z});
 }
 // Mall tenants stay on the mall's directory, not invented standalone street shops.
 const mall=LANDMARKS[0],mallX=mall.x+mall.w/2+.3;
 sign('PHOENIX MARKETCITY',mallX,17,mall.z,63,3.4,Math.PI/2,0x274e55);
 sign('INSIDE THE MALL',mallX,13.3,mall.z,38,1.7,Math.PI/2,0x274e55);
 STORE_DATA.filter(s=>s.mall).forEach((shop,i)=>{sign(shop.name,mallX+.1,10-(i%3)*2.5,mall.z-16+Math.floor(i/3)*32,28,1.65,Math.PI/2,0x42646a);});
 const shops=['FILTER COFFEE','TIFFIN & TEA','NEIGHBOURHOOD GROCERY','FRUIT & VEG','CYCLE REPAIRS','FRESH BAKERY'];

 for(const road of roads)for(let i=4;i<road.points.length-5;i+=road.interior?7:6){const p=road.points[i],a=road.points[i-1],b=road.points[i+1],angle=Math.atan2(b.x-a.x,b.z-a.z),nx=Math.cos(angle),nz=-Math.sin(angle);
  for(const side of [-1,1]){const d=12+rand()*13,w=13+rand()*20,offset=road.width/2+12+d/2,x=p.x+nx*offset*side,z=p.z+nz*offset*side;
   if(storefronts.some(s=>Math.hypot(x-s.x,z-s.z)<Math.max(s.w,s.d)/2+35)||nearestOnRoad(roads,x,z).distance<offset-3||LANDMARKS.some(l=>Math.abs(x-l.x)<l.w/2+35&&Math.abs(z-l.z)<l.d/2+35))continue;
   const h=6+Math.floor(rand()*4)*3.2;building(x,z,w,d,h,colors[Math.floor(rand()*colors.length)],angle);
   if(i%15===4){const sy=side===1?Math.PI:0,sx=x-Math.sin(angle)*d*.51,sz=z-Math.cos(angle)*d*.51;sign(shops[Math.floor(rand()*shops.length)],sx,3.8,sz,Math.min(w*.88,19),1.4,angle+Math.PI);}
  }
 }
 // Distant blocks are sparse and deterministic, with no live spawning or downloads.
 for(let i=0;i<480;i++){const x=MAP_BOUNDS.minX+rand()*(MAP_BOUNDS.maxX-MAP_BOUNDS.minX),z=MAP_BOUNDS.minZ+rand()*(MAP_BOUNDS.maxZ-MAP_BOUNDS.minZ),near=nearestOnRoad(roads,x,z);if(storefronts.some(s=>Math.hypot(x-s.x,z-s.z)<65)||near.distance<70||LANDMARKS.some(l=>Math.abs(x-l.x)<l.w/2+40&&Math.abs(z-l.z)<l.d/2+40))continue;const w=14+rand()*24,d=14+rand()*24,h=8+rand()*27;building(x,z,w,d,h,colors[Math.floor(rand()*colors.length)],0,false);if(i%3===0)tree(x+w,z+8);}
 // Roadside bus shelters, tea stalls and parked auto-rickshaws add a local street rhythm.
 // Street names from OSM; position boards on a verified clear verge.
 for(const road of roads)for(let i=30;i<road.points.length;i+=68){const p=road.points[i],a=road.points[i-1],ang=Math.atan2(p.x-a.x,p.z-a.z),nx=Math.cos(ang),nz=-Math.sin(ang),x=p.x+nx*(road.width/2+3),z=p.z+nz*(road.width/2+3);if(roadClearance(roads,x,z)<.6)continue;cube(x,3,z,.14,6,.14,0x627e7b);sign(road.name.toUpperCase(),x,5.7,z,9,1.1,ang+Math.PI,0x16534b);}
 for(const b of batches.values()){const mesh=new T.InstancedMesh(b.geo,b.mat,b.items.length);b.items.forEach((v,i)=>{tmp.position.set(v[0],v[1],v[2]);tmp.scale.set(v[3],v[4],v[5]);tmp.rotation.set(0,v[6],v[7]);tmp.updateMatrix();mesh.setMatrixAt(i,tmp.matrix);if(b===batches.get('boxes'))mesh.setColorAt(i,new T.Color(v[8]));});mesh.instanceMatrix.needsUpdate=true;mesh.castShadow=true;mesh.receiveShadow=true;mesh.computeBoundingSphere();scene.add(mesh);}
 function sign(text,x,y,z,w,h,ry=0,bg=0x2c5255){const cv=document.createElement('canvas');cv.width=1024;cv.height=128;const ctx=cv.getContext('2d');ctx.fillStyle='#'+bg.toString(16).padStart(6,'0');ctx.fillRect(0,0,1024,128);ctx.strokeStyle='#c5d3bb';ctx.lineWidth=5;ctx.strokeRect(9,9,1006,110);ctx.fillStyle='#fcf4db';ctx.font='600 57px Arial';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(text,512,68,960);const tex=new T.CanvasTexture(cv);tex.colorSpace=T.SRGBColorSpace;const m=new T.Mesh(new T.PlaneGeometry(w,h),new T.MeshBasicMaterial({map:tex,side:T.DoubleSide}));m.userData.label=text;m.userData.signColor='#'+bg.toString(16).padStart(6,'0');m.position.set(x,y,z);m.rotation.y=ry;scene.add(m);}
 return{roads,boundary,places:PLACES,buildings,storefronts,trees,lampPosts,routeLength:roads.reduce((sum,r)=>sum+r.points.slice(1).reduce((s,p,i)=>s+p.distanceTo(r.points[i]),0),0),nearest:(x,z)=>nearestOnRoad(roads,x,z)};
}

export function createCar(scene){
 const car=new T.Group();car.userData.dynamic=true;scene.add(car);const paint=new T.MeshPhysicalMaterial({color:0x9b163b,roughness:.23,metalness:.4,clearcoat:1,clearcoatRoughness:.12}),trim=new T.MeshStandardMaterial({color:0x172a30,roughness:.65}),glass=new T.MeshStandardMaterial({color:0x284f5e,roughness:.18,metalness:.38}),silver=new T.MeshStandardMaterial({color:0xaab8b8,roughness:.26,metalness:.72});
 function part(w,h,d,x,y,z,material,rotation=0){const m=new T.Mesh(material===glass&&w>1?cabinGeometry(w,h,d):roundedBox(w,h,d),material);m.position.set(x,y,z);m.rotation.x=rotation;m.castShadow=true;m.receiveShadow=true;car.add(m);return m;}
 part(1.78,.5,4.15,0,.05,0,paint);part(1.79,.18,4.18,0,-.24,0,trim);part(1.65,.15,1.25,0,.37,-1.36,paint);
 part(1.55,.73,2.7,0,.57,.5,glass);part(1.48,.12,2.42,0,.98,.62,paint);
 for(const x of [-.77,.77]){part(.09,.77,.12,x,.57,-.68,paint,.43);part(.1,.77,.12,x,.57,.35,paint);part(.12,.77,.18,x,.57,1.76,paint,.12);part(.1,.1,2.1,x,.23,.18,paint);part(.055,.055,2.2,x,.11,.2,silver);part(.28,.15,.19,x*1.2,.52,-.83,paint);part(.04,.05,.23,x*1.07,.26,.2,silver);part(.04,.05,.23,x*1.07,.26,1,silver);part(.08,.06,1.6,x*.86,1.09,.3,trim);}
 part(1.3,.25,.06,0,.01,-2.09,trim);for(const y of [-.07,.02,.11])part(1.28,.025,.08,0,y,-2.13,silver);
 const headMat=new T.MeshStandardMaterial({color:0xe7e8cd,emissive:0xffffcb,emissiveIntensity:.15}),brakeMat=new T.MeshStandardMaterial({color:0xa50921,emissive:0xff172b,emissiveIntensity:.2}),reverseMat=new T.MeshStandardMaterial({color:0xbec7bf,emissive:0xffffff,emissiveIntensity:0});
 for(const x of [-.65,.65]){part(.4,.15,.06,x,.16,-2.1,headMat);part(.4,.16,.07,x,.17,2.1,brakeMat);part(.18,.055,.075,x*.82,-.05,2.11,reverseMat);}
 part(.65,.15,.075,0,-.09,2.12,new T.MeshStandardMaterial({color:0xf0e6ce}));part(1.55,.06,.14,0,.94,1.91,trim);
 const indicatorMats=[-1,1].map(()=>new T.MeshStandardMaterial({color:0xc67520,emissive:0xff9a12,emissiveIntensity:0}));for(let i=0;i<2;i++)for(const z of [-2.105,2.105])part(.12,.1,.07,i===0?-.83:.83,.18,z,indicatorMats[i]);
 const wheelGeo=new T.CylinderGeometry(.335,.335,.215,32);wheelGeo.rotateZ(Math.PI/2);const hubGeo=new T.CylinderGeometry(.215,.215,.221,24);hubGeo.rotateZ(Math.PI/2);
 const wheels=[];for(let i=0;i<4;i++){const g=new T.Group(),tire=new T.Mesh(wheelGeo,trim),hub=new T.Mesh(hubGeo,silver);g.userData.dynamic=true;g.add(tire,hub);for(let j=0;j<5;j++){const spoke=new T.Mesh(roundedBox(.228,.032,.32,.01),silver);spoke.rotation.x=j*Math.PI/5;g.add(spoke);}tire.castShadow=true;hub.castShadow=true;scene.add(g);wheels.push(g);}
 // Soft contact shadow is cheap even when real-time shadows are disabled.
 const cv=document.createElement('canvas');cv.width=cv.height=64;const ctx=cv.getContext('2d'),gr=ctx.createRadialGradient(32,32,8,32,32,32);gr.addColorStop(0,'rgba(0,0,0,.45)');gr.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=gr;ctx.fillRect(0,0,64,64);const shadow=new T.Mesh(new T.PlaneGeometry(3.6,6.1),new T.MeshBasicMaterial({map:new T.CanvasTexture(cv),transparent:true,depthWrite:false}));shadow.rotation.x=-Math.PI/2;scene.add(shadow);
 return{car,wheels,headMat,brakeMat,reverseMat,indicatorMats,shadow};
}
