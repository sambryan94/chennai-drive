"""Reproduce the bounded road selection: python scripts/import-osm.py export.json.
Requires Shapely 2.x for offline clipping only. No runtime API calls or raster tiles.
Input: Overpass `out body geom` export; see MAP_DATA.md for query/license.
"""
import json, math, sys
from pathlib import Path
from collections import defaultdict
from shapely.geometry import LineString, box, Point
from shapely.ops import unary_union, polygonize

ROOT = Path(__file__).resolve().parents[1]
raw = json.loads(Path(sys.argv[1]).read_text())
ways = [e for e in raw['elements'] if e['type']=='way' and len(e.get('geometry', []))>1 and 'highway' in e.get('tags',{})]
def line(e): return LineString([(p['lon'],p['lat']) for p in e['geometry']])
major_types = {'primary','secondary','trunk','primary_link','secondary_link','trunk_link'}
polygons = sorted(polygonize(unary_union([line(e) for e in ways if e['tags']['highway'] in major_types])), key=lambda p:p.area, reverse=True)
# Closed OSM block enclosed by the real bypass, main road and Vijayanagar links.
interior = next(p for p in polygons if p.area>.00001 and p.bounds[0]>80.217 and p.covers(Point(80.220,12.985)))
bounds = [80.2038,12.9676,80.225,13.014]
clip = box(*bounds)
main_names = {'Velachery Main Road','Velachery Bypass Road','100 Feet Road','Inner Ring Road (Southern Sector)','Anna Salai (Mount Road)','Guindy Bridge','Sardar Patel Road','Taluk Office Road','Taramani Link Road','Taramani Road'}
base = [e for e in ways if e['tags'].get('name') in main_names and line(e).intersects(clip)]
main_union = unary_union([line(e) for e in base])
selected=[]
for e in ways:
    t=e['tags']; l=line(e)
    if t.get('access') in ('private','no') or t.get('motor_vehicle')=='no': continue
    local=t['highway'] in ('residential','tertiary','unclassified','living_street') and interior.buffer(.000025).covers(l)
    link=(t['highway'].endswith('_link') or (t['highway']=='primary' and not t.get('name'))) and t.get('bridge')!='yes' and int(t.get('layer','0'))==0 and main_union.distance(l)<.00015
    if e in base or local or link:
        cut=l.intersection(clip)
        for part in ([cut] if cut.geom_type=='LineString' else getattr(cut,'geoms',[])):
            if part.geom_type=='LineString' and part.length>.000015:
                selected.append({'id':e['id'],'tags':t,'coordinates':list(part.coords),'interior':local})
# Prune disconnected ways by actual shared coordinates (not overpass crossings).
nodes=defaultdict(list)
for i,e in enumerate(selected):
    for c in e['coordinates']: nodes[tuple(c)].append(i)
seen=set(); groups=[]
for i in range(len(selected)):
    if i in seen: continue
    todo=[i];group=set()
    while todo:
        j=todo.pop()
        if j in seen: continue
        seen.add(j);group.add(j)
        for c in selected[j]['coordinates']: todo.extend(k for k in nodes[tuple(c)] if k not in seen)
    groups.append(group)
largest=max(groups,key=lambda g:sum(LineString(selected[i]['coordinates']).length for i in g))
selected=[e for i,e in enumerate(selected) if i in largest]
origin={'lat':12.99,'lon':80.2195}; scale=111195.0802335329
def project(c): return [round((c[0]-origin['lon'])*scale*math.cos(math.radians(origin['lat'])),3),round((origin['lat']-c[1])*scale,3)]
roads=[]
for e in selected:
    t=e['tags']; oneway=1 if t.get('oneway')=='yes' else -1 if t.get('oneway')=='-1' else 0
    # Widths are gameplay approximations; retain carriageway geometry and direction.
    width=7 if e['interior'] else 7 if oneway else 14
    if t.get('width','').replace('.','',1).isdigit(): width=max(5.5,min(18,float(t['width'])))
    name=t.get('name') or ('Neighbourhood lane' if e['interior'] else 'Junction connector')
    roads.append({'name':name,'osmIds':[e['id']],'width':width,'oneway':oneway,'interior':e['interior'],'bridge':t.get('bridge')=='yes','points':[project(c) for c in e['coordinates']]})
# Join matching consecutive ways while preserving every OSM vertex and junction.
changed=True
while changed:
    changed=False
    for i,a in enumerate(roads):
        for j in range(i+1,len(roads)):
            b=roads[j]
            if any(a[k]!=b[k] for k in ('name','width','oneway','interior','bridge')): continue
            ap,bp=a['points'],b['points']; merged=None
            if ap[-1]==bp[0]: merged=ap+bp[1:]
            elif bp[-1]==ap[0]: merged=bp+ap[1:]
            elif not a['oneway'] and ap[-1]==bp[-1]: merged=ap+bp[-2::-1]
            elif not a['oneway'] and ap[0]==bp[0]: merged=ap[::-1]+bp[1:]
            if merged:
                a['points']=merged;a['osmIds']+=b['osmIds'];roads.pop(j);changed=True;break
        if changed: break
roads.sort(key=lambda r:(r['interior'],r['name']!='Velachery Main Road',-len(r['points'])))
meta={'source':'OpenStreetMap contributors','license':'ODbL-1.0','licenseUrl':'https://opendatacommons.org/licenses/odbl/1-0/','attributionUrl':'https://www.openstreetmap.org/copyright','exportTimestamp':raw.get('osm3s',{}).get('timestamp_osm_base'),'origin':origin,'bounds':bounds,'interiorBoundary':list(interior.exterior.coords),'projection':'Local equirectangular metres, X east / Z south','elevation':'Flat gameplay surface; no surveyed elevation or drivable multilevel interchange','roadWays':len(selected),'interiorNames':sorted({r['name'] for r in roads if r['interior'] and r['name']!='Neighbourhood lane'})}
out=ROOT/'public/game/data';out.mkdir(exist_ok=True)
(out/'roads.geojson').write_text(json.dumps({'type':'FeatureCollection','metadata':meta,'features':[{'type':'Feature','properties':{'osmId':e['id'],**e['tags'],'interior':e['interior']},'geometry':{'type':'LineString','coordinates':e['coordinates']}} for e in selected]},separators=(',',':')))
(out/'roads-data.js').write_text('// Derived from OpenStreetMap; ODbL 1.0. See roads.geojson and MAP_DATA.md.\nexport const MAP_META='+json.dumps(meta,separators=(',',':'))+';\nexport const OSM_ROADS='+json.dumps(roads,separators=(',',':'))+';\n')
print(json.dumps({'ways':len(selected),'routes':len(roads),'interiorNames':meta['interiorNames'],'prunedComponents':[len(g) for g in groups if g!=largest],'kilometres':sum(sum(math.dist(a,b) for a,b in zip(r['points'],r['points'][1:])) for r in roads)/1000},indent=2))
