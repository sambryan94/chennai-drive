import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as T from '../public/game/vendor/three.module.js';
import * as C from '../public/game/vendor/cannon-es.js';
import {createPhysics} from '../public/game/vehicle.js';
import {createWorld,createCar} from '../public/game/world.js';
import {createSignals} from '../public/game/signals.js';
import {createNightMode} from '../public/game/night-mode.js';
import {ROAD_DATA,MAP_META,MAP_BOUNDS,SPAWN,toGeo,fromGeo,roadClearance,insideMap} from '../public/game/roads.js';
const results=[],check=(name,ok,details={})=>{assert.ok(ok,name+' '+JSON.stringify(details));results.push({name,status:'PASS',...details});};
const data=JSON.parse(fs.readFileSync(new URL('../public/game/data/roads.geojson',import.meta.url)));
const sourceVertices=new Set(data.features.flatMap(f=>f.geometry.coordinates.map(c=>c.join(','))));
let maxError=0;for(const r of ROAD_DATA)for(const p of r.points){const geo=toGeo(...p);let closest=Infinity;for(const id of r.osmIds){const f=data.features.find(f=>f.properties.osmId===id);if(f)for(const c of f.geometry.coordinates)closest=Math.min(closest,Math.hypot((geo.lon-c[0])*108350,(geo.lat-c[1])*111195));}maxError=Math.max(maxError,closest);}
check('Road vertices preserve exported geographic positions',maxError<.01,{maximumMetreError:maxError});
const names=new Set(MAP_META.interiorNames.map(n=>n.toLowerCase().replace('10th','10')));
check('At least ten named interior streets come from OSM',names.size>=10,{distinctNames:names.size});
// Every included line belongs to one network through actual shared OSM vertices.
const nodes=new Map();data.features.forEach((f,i)=>f.geometry.coordinates.forEach(c=>{const key=c.join(',');if(!nodes.has(key))nodes.set(key,[]);nodes.get(key).push(i);}));
const seen=new Set(),todo=[0];while(todo.length){const i=todo.pop();if(seen.has(i))continue;seen.add(i);for(const c of data.features[i].geometry.coordinates)for(const j of nodes.get(c.join(',')))if(!seen.has(j))todo.push(j);}
check('All selected roads connect without invented linking segments',seen.size===data.features.length,{ways:seen.size});
const noop=()=>{},ctx={fillRect:noop,strokeRect:noop,fillText:noop,createRadialGradient:()=>({addColorStop:noop})};globalThis.document={createElement:()=>({getContext:()=>ctx})};
const p=createPhysics(),scene=new T.Scene(),map=createWorld(scene,p),sig=createSignals(scene,p,map.roads),idle={throttle:0,brake:0,steer:0,handbrake:false,boost:false};
const heads=sig.junctions.flatMap(j=>j.heads);
check('All five signalized junctions have visible sidewalk heads',sig.junctions.length===5&&sig.junctions.every(j=>j.heads.length>0),{heads:heads.length});
check('Every signal body clears every road, including crossing carriageways',heads.every(h=>roadClearance(map.roads,h.g.position.x,h.g.position.z)>1));
let contacts=0;for(const r of map.roads.filter(r=>r.interior)){const mid=Math.floor(r.points.length/2),a=r.points[mid],b=r.points[Math.min(mid+1,r.points.length-1)];const heading=Math.atan2(a.x-b.x,a.z-b.z);p.reset(a.x,a.z,heading);for(let i=0;i<70;i++)p.step(1/60,idle);const roadWheels=p.vehicle.wheelInfos.filter(w=>w.raycastResult.body?.propType==='road').length;assert.ok(roadWheels>=3,'Missing road collision: '+r.name);contacts++;}
check('Every interior route has actual drivable mesh collision',contacts>=10,{interiorRoutes:contacts});
const n=map.nearest(SPAWN.x,SPAWN.z);p.reset(n.x,n.z,n.heading);for(let i=0;i<90;i++)p.step(1/60,idle);check('Geographic starting point settles onto the real road',p.state.contacts===4&&p.vehicle.wheelInfos.every(w=>w.raycastResult.body?.propType==='road'));
const b=MAP_BOUNDS,edges=[{x:b.minX+20,z:(b.minZ+b.maxZ)/2,vx:-50,vz:0,h:Math.PI/2},{x:b.maxX-20,z:(b.minZ+b.maxZ)/2,vx:50,vz:0,h:-Math.PI/2},{x:(b.minX+b.maxX)/2,z:b.minZ+20,vx:0,vz:-50,h:0},{x:(b.minX+b.maxX)/2,z:b.maxZ-20,vx:0,vz:50,h:Math.PI}];
let boundaryHits=0;p.chassis.addEventListener('collide',e=>{if(e.body.propType==='boundary')boundaryHits++;});
for(const e of edges){p.reset(e.x,e.z,e.h);for(let i=0;i<90;i++)p.step(1/60,idle);p.chassis.velocity.set(e.vx,0,e.vz);for(let i=0;i<120;i++)p.step(1/60,idle);assert.ok(insideMap(p.chassis.position.x,p.chassis.position.z),'Boundary breach');}
check('All four map edges physically contain a turbo-speed collision',boundaryHits>=4,{boundaryHits,segments:map.boundary.segments.length});
check('All lamps use 50-metre route stations and clear the road union',map.lampPosts.every(l=>(l.distance-25)%50===0&&roadClearance(map.roads,l.x,l.z)>.8),{lamps:map.lampPosts.length});
scene.background=new T.Color(0xc2d7d3);scene.fog=new T.Fog(0xc2d7d3,150,1000);const car=createCar(scene),ambient=new T.HemisphereLight(),sun=new T.DirectionalLight(),renderer={software:false,setNight:noop},props={items:map.lampPosts};const night=createNightMode(scene,renderer,sun,ambient,car,map,props);
night.set(true);night.update({position:{x:map.storefronts[0].x,z:map.storefronts[0].z}},true);
check('Shopfronts and occupied building windows emit night light',night.facadeLights.some(l=>l.kind==='shop')&&night.facadeLights.some(l=>l.kind==='building')&&night.strips.some(s=>s.visible)&&scene.userData.nightLights.length>0,{emitters:night.facadeLights.length});
night.set(false);check('Day mode disables pooled night illumination',scene.userData.nightLights.length===0&&ambient.intensity===2.6);
check('Packaged map has downloadable data and attribution metadata',data.metadata.license==='ODbL-1.0'&&data.metadata.attributionUrl==='https://www.openstreetmap.org/copyright');
console.log(JSON.stringify({tests:results.length,results},null,2));
