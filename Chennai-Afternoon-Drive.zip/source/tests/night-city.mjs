import assert from 'node:assert/strict';
import * as T from '../public/game/vendor/three.module.js';
import * as C from '../public/game/vendor/cannon-es.js';
import {createBoost} from '../public/game/boost.js';
import {createPhysics} from '../public/game/vehicle.js';
import {createWorld} from '../public/game/world.js';
import {createStreetProps,sweptFootprint} from '../public/game/street-props.js';
import {createSignals,signalPhase} from '../public/game/signals.js';
import {createPedestrians,PEDESTRIAN_COUNT} from '../public/game/pedestrians.js';
import {createTraffic,sampleLane} from '../public/game/traffic.js';
const results=[],idle={throttle:0,brake:0,steer:0,handbrake:false,boost:false},check=(name,ok,details={})=>{assert.ok(ok,name+JSON.stringify(details));results.push({name,status:'PASS',...details});};
let boost=createBoost(),active=0,state;for(let i=0;i<1500;i++){state=boost.update(1/60,true,true);if(state.boost)active++;}check('Holding turbo cannot exceed eight seconds or restart itself',active===480&&state.boostLocked,{activeSeconds:active/60});
boost.update(1/60,false,true);check('Release rearms a recharged reserve',boost.update(1/60,true,true).boost);
boost=createBoost();for(let i=0;i<480;i++)boost.update(1/60,true,true);for(let i=0;i<960;i++)state=boost.update(1/60,false,true);check('Empty reserve fully refills in sixteen seconds',Math.abs(state.boostRemaining-8)<1e-6);
boost=createBoost();for(let i=0;i<60;i++)state=boost.update(1/60,true,false);check('Ineligible boost does not consume reserve',state.boostRemaining===8&&!state.boost);
const p=createPhysics();for(let i=0;i<120;i++)p.step(1/60,{...idle,throttle:1,boost:true});const reserve=p.state.boostRemaining;p.reset(0,0);for(let i=0;i<75;i++)p.step(1/60,idle,false,false);check('Recovery settlement does not award free boost',p.state.boostRemaining===reserve);
const noop=()=>{};globalThis.document={createElement:()=>({getContext:()=>({fillRect:noop,strokeRect:noop,fillText:noop})})};
const scene=new T.Scene(),physical=createPhysics(),map=createWorld(scene,physical);check('Every generated tree has a fixed collision body',map.trees.length>100&&map.trees.every(t=>t.body.type===C.Body.STATIC&&t.body.propType==='tree'),{trees:map.trees.length});
// A representative generated trunk on the real scene, approached directly from the south.
const tree=map.trees.slice().sort((a,b)=>Math.hypot(a.x-525,a.z-900)-Math.hypot(b.x-525,b.z-900))[0];let hitTree=false;physical.chassis.addEventListener('collide',e=>{if(e.body===tree.body)hitTree=true;});physical.reset(tree.x,tree.z+12,0);for(let i=0;i<90;i++)physical.step(1/60,idle);physical.chassis.velocity.set(0,0,-14);for(let i=0;i<240;i++)physical.step(1/60,idle);check('Real generated tree stops the SUV without penetration',hitTree&&physical.chassis.position.z>tree.z+1.8&&Math.abs(physical.state.speed)<.4,{speed:physical.state.speed,clearance:physical.chassis.position.z-tree.z});
const lp=createPhysics(),posts=createStreetProps(new T.Scene(),lp,[{x:0,z:0,angle:0,side:1,nx:1,nz:0}]);lp.reset(0,12);for(let i=0;i<90;i++)lp.step(1/60,idle);lp.chassis.velocity.set(0,0,-14);let impactBefore=0,impactAfter=0;
for(let i=0;i<480;i++){const previous=posts.impacts,before=lp.chassis.velocity.length();posts.beforeStep(1/60,lp.chassis);if(posts.impacts>previous){impactBefore=before;impactAfter=lp.chassis.velocity.length();}lp.step(1/60,idle);posts.sync(lp.chassis);}
const up=posts.items[0].body.quaternion.vmult(new C.Vec3(0,1,0));check('Lamp impact knocks down exactly one physical post',posts.impacts===1&&posts.items[0].fallen&&Math.abs(up.y)<.3,{upY:up.y});check('Lamp impact slows the car',impactAfter<impactBefore*.8&&impactAfter>0,{before:impactBefore,after:impactAfter});check('Fallen lamp visual follows its body and stays down',posts.items[0].group.position.distanceTo(new T.Vector3(...posts.items[0].body.position.toArray()))<.001&&!posts.items[0].lamp.visible);
check('Near misses do not knock posts down',!sweptFootprint(1.3,1,0,-.4)&&sweptFootprint(0,2.5,0,-.9));
for(let time=0;time<100;time+=.1){const states=[0,1,2].map(i=>signalPhase(time,3,i));assert.ok(states.filter(x=>x==='green'||x==='amber').length<=1);if(states.includes('walk'))assert.ok(states.every(x=>x==='walk'));}check('Signal cycle separates conflicting traffic and pedestrian phases',true);
const sig=createSignals(scene,physical,map.roads),ped=createPedestrians(scene,map.roads,sig);check('Five visible signalized crossings use the road network',sig.junctions.length===5&&sig.junctions.every(j=>j.heads.length>=1));
const first=sig.junctions[0],route=sig.routes[first.approaches[0].routeIndex],car={routeIndex:first.approaches[0].routeIndex,distance:first.approaches[0].stops[1]-8,direction:1,length:4.3,speed:8};sig.update(15);check('Red signal tells approaching traffic to stop before the line',sig.speedLimit(car)<5,{limit:sig.speedLimit(car)});
// One real pooled traffic vehicle responds to the signal control, while its other cars are away.
const tp=createPhysics(),traffic=createTraffic(new T.Scene(),tp,map,sig),lead=traffic.items[0];for(const item of traffic.items)item.distance=20;Object.assign(lead,car);lead.pose=sampleLane(route,car.distance,1);lead.speed=8;tp.reset(9999,9999);
for(let i=0;i<480;i++){traffic.update(1/60,tp.chassis);tp.step(1/60,idle);}check('Traffic actually halts at a red light',lead.speed<.15&&lead.distance<first.approaches[0].stops[1],{speed:lead.speed});while(sig.phase(first,0)!=='green')sig.update(.1);for(let i=0;i<180;i++){traffic.update(1/60,tp.chassis);tp.step(1/60,idle);}check('Traffic resumes when its signal turns green',lead.speed>1,{speed:lead.speed});
let sawCrossing=false,moved=0;const far={position:{x:9999,z:9999}};ped.update(0,far);const start=ped.items[20].group.position.clone();for(let i=0;i<6000;i++){sig.update(1/60);ped.update(1/60,far);if(ped.crossings.length)sawCrossing=true;}moved=ped.items[20].group.position.distanceTo(start);check('Bounded pedestrian pool walks and uses the walk phase',ped.items.length===PEDESTRIAN_COUNT&&sawCrossing&&moved>10,{pedestrians:ped.items.length,moved});
console.log(JSON.stringify({tests:results.length,results},null,2));
