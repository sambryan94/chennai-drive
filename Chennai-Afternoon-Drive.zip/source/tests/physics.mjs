import assert from 'node:assert/strict';
import {createPhysics,TUNING} from '../public/game/vehicle.js';
import {createSignals} from '../public/game/signals.js';
import {createWorld} from '../public/game/world.js';
import * as THREE from '../public/game/vendor/three.module.js';
const results=[];const idle={throttle:0,brake:0,steer:0,handbrake:false};
const run=(p,n,input=idle)=>{for(let i=0;i<n;i++)p.step(1/60,input);};
const check=(name,condition,details)=>{assert.ok(condition,name+': '+JSON.stringify(details));results.push({test:name,status:'PASS',details});};
const p=createPhysics();run(p,120);check('Four suspension contacts at rest',p.state.contacts===4&&p.chassis.position.y>.4,{contacts:p.state.contacts,y:p.chassis.position.y});
run(p,240,{...idle,throttle:1});check('Forward acceleration and distance',p.state.speed>8&&p.chassis.position.z<890,{speed:p.state.speed,z:p.chassis.position.z});
run(p,90,{...idle,brake:1});check('Progressive braking stops car',Math.abs(p.state.speed)<1,{speed:p.state.speed});
run(p,180,{...idle,brake:1});check('Automatic reverse',p.state.speed<-2&&p.state.gear==='R',{speed:p.state.speed,gear:p.state.gear});
p.reset(0,0,0);run(p,90);run(p,180,{...idle,throttle:1});run(p,120,{...idle,throttle:1,steer:.45});check('Left input turns left',p.chassis.position.x<-1,{x:p.chassis.position.x});
run(p,180,{...idle,handbrake:true});check('Handbrake stops car',Math.abs(p.state.speed)<.2,{speed:p.state.speed});
p.reset(0,0,0);run(p,90);run(p,3600,{...idle,throttle:1});check('Maximum speed remains limited',p.state.speed>15&&p.state.speed<=TUNING.maxSpeed+.5,{kmh:p.state.speed*3.6});
// Exercise the identical generated road/collision scene. Text canvases are stubbed,
// because these tests inspect physics geometry, not rendering.
const noop=()=>{};globalThis.document={createElement:()=>({width:0,height:0,getContext:()=>({fillRect:noop,strokeRect:noop,fillText:noop})})};
const mapPhysics=createPhysics(),map=createWorld(new THREE.Scene(),mapPhysics);createSignals(new THREE.Scene(),mapPhysics,map.roads);let sampled=0,minContacts=4,minY=Infinity;
for(const road of map.roads)for(let i=0;i<road.points.length-1;i+=25){const a=road.points[i],b=road.points[i+1],heading=Math.atan2(a.x-b.x,a.z-b.z);const lane=road.oneway?0:Math.min(3.2,road.width*.23);mapPhysics.reset(a.x-Math.cos(heading)*lane,a.z+Math.sin(heading)*lane,heading);run(mapPhysics,80);sampled++;minContacts=Math.min(minContacts,mapPhysics.state.contacts);minY=Math.min(minY,mapPhysics.chassis.position.y);assert.ok(mapPhysics.state.contacts>=3&&mapPhysics.chassis.position.y>.3,'Road sample failed: '+road.name+' '+i);}
check('Road coverage and safe spawn samples',sampled>100,{samples:sampled,minContacts,minY,networkKilometres:map.routeLength/1000});
// A head-on collision must block progress through a building-sized solid obstacle.
const wall=createPhysics();wall.box(0,-18,15,3,6);wall.reset(0,0,0);run(wall,90);run(wall,600,{...idle,throttle:1});check('Obstacle collision blocks vehicle',wall.chassis.position.z>-16.5&&Number.isFinite(wall.state.speed),{z:wall.chassis.position.z,speed:wall.state.speed});
console.log(JSON.stringify({tests:results.length,results},null,2));
