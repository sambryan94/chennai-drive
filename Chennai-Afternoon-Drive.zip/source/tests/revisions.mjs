import assert from 'node:assert/strict';
import {createTransmission} from '../public/game/transmission.js';
import {createPhysics} from '../public/game/vehicle.js';
import {createPointerState} from '../public/game/touch-input.js';
import {engineVoice} from '../public/game/audio.js';
import {fitMap} from '../public/game/minimap.js';
import {STORE_DATA} from '../public/game/stores.js';
const results=[];const check=(name,condition,data={})=>{assert.ok(condition,name+': '+JSON.stringify(data));results.push({name,status:'PASS',...data});};
const p=createPhysics(),idle={throttle:0,brake:0,steer:0,handbrake:false};for(let i=0;i<90;i++)p.step(1/60,idle);
let drops=[],previous=p.state.rpm,oldGear=1,pending=null;
for(let i=0;i<1800;i++){
 p.step(1/60,{...idle,throttle:1});
 if(p.state.gearNumber>oldGear)pending={rpm:previous,gear:p.state.gearNumber,time:i};
 if(pending&&i-pending.time===22){drops.push({gear:pending.gear,drop:Math.round(pending.rpm-p.state.rpm)});pending=null;}
 oldGear=p.state.gearNumber;previous=p.state.rpm;
}
check('Actual driven vehicle upshifts with audible RPM drops',drops.length>=2&&drops.every(x=>x.drop>350),{drops,topGear:p.state.gearNumber});
const t=createTransmission(),gears=new Set();
for(let i=0;i<3600;i++){t.update(1/60,Math.min(30,i/70),.25);gears.add(t.state.gearNumber);}
check('All six forward gears are reachable',gears.size===6,{gears:[...gears]});
const shifts=t.state.shiftCount;for(let i=0;i<600;i++)t.update(1/60,30+Math.sin(i)*.05,.25);
check('Cruise hysteresis prevents gear hunting',t.state.shiftCount===shifts);
t.update(1/60,-3,1,'R');check('Reverse clears forward gear state',t.state.gearNumber===1&&!t.state.shifting);t.reset();check('Reset returns engine to idle',t.state.rpm===820&&t.state.shiftCount===0);
const pointer=createPointerState();pointer.press(1,'throttle');pointer.press(2,'left');
check('Two fingers accelerate and steer together',pointer.state.throttle===1&&pointer.state.steer===1);
pointer.press(3,'throttle');pointer.release(1);check('Lifting one of two fingers on GO preserves the other',pointer.state.throttle===1);
pointer.release(2);check('Steering release leaves accelerator held',pointer.state.steer===0&&pointer.state.throttle===1);
pointer.press(4,'brake');pointer.release(3);check('Brake remains held independently',pointer.state.brake===1&&pointer.state.throttle===0);pointer.clear();check('Pause or focus loss releases all pedals',pointer.state.brake===0&&pointer.state.steer===0&&pointer.state.throttle===0);
for(const [w,h] of [[310,232.5],[148,111],[164,82]]){const points=[{x:-1360,z:-1100},{x:1200,z:1400}],fit=fitMap(points,w,h,16),a=fit.project(0,0),x=fit.project(100,0),z=fit.project(0,100);check('Map keeps equal metre scale '+w+'px',Math.abs((x.x-a.x)-(z.y-a.y))<1e-9&&points.every(p=>{const q=fit.project(p.x,p.z);return q.x>=15&&q.x<=w-15&&q.y>=15&&q.y<=h-15;}));}
const low=engineVoice(900,.1,0,false),high=engineVoice(3500,1,15,false),shift=engineVoice(2200,.15,15,true);
check('Engine pitch, timbre and shift envelope vary',high.pulseHz>low.pulseHz*3&&high.cutoff>low.cutoff&&shift.gain<high.gain&&high.rolling>0);
check('Curated businesses carry provenance and distinguish mall tenants',STORE_DATA.length===10&&STORE_DATA.every(s=>s.source.startsWith('https://')&&(s.address||s.osmId))&&STORE_DATA.filter(s=>s.mall).length===6);
console.log(JSON.stringify({tests:results.length,results},null,2));
