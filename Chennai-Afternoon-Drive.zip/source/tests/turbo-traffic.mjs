import assert from 'node:assert/strict';
import * as T from '../public/game/vendor/three.module.js';
import {createPhysics,TUNING} from '../public/game/vehicle.js';
import {createTraffic,prepareTrafficRoutes,sampleLane,TRAFFIC_COUNT} from '../public/game/traffic.js';
import {gaugeAngle} from '../public/game/instruments.js';
import {createPointerState} from '../public/game/touch-input.js';
const results=[],idle={throttle:0,brake:0,steer:0,handbrake:false,boost:false};
const check=(name,condition,details={})=>{assert.ok(condition,name+JSON.stringify(details));results.push({name,status:'PASS',...details});};
const p=createPhysics();for(let i=0;i<90;i++)p.step(1/60,idle);let gears=new Set();
for(let i=0;i<7200;i++){p.step(1/60,{...idle,throttle:1});gears.add(p.state.gearNumber);}
check('Normal driving reaches 120 display in sixth gear',p.state.speed*3.6>=119.5&&p.state.speed<=TUNING.maxSpeed+.1&&gears.size===6,{kmh:p.state.speed*3.6,gears:[...gears]});
for(let i=0;i<480;i++)p.step(1/60,{...idle,throttle:1,boost:true});
check('Eight-second burst reaches 180 display from normal cruising speed',p.state.speed*3.6>179.5&&p.state.speed<=TUNING.turboSpeed+.1&&p.state.contacts===4,{kmh:p.state.speed*3.6});
for(let i=0;i<2700;i++)p.step(1/60,{...idle,throttle:1});check('Releasing turbo returns to normal limiter',Math.round(p.state.speed*3.6)===120&&!p.state.boost);
p.reset(0,0);for(let i=0;i<60;i++)p.step(1/60,{...idle,throttle:1,boost:true,brake:1});check('Brake suppresses turbo',!p.state.boost);
const pointers=createPointerState();pointers.press(1,'boost');pointers.press(2,'left');check('Turbo and steering support independent fingers',pointers.state.boost&&pointers.state.steer===1);pointers.release(1);check('Turbo release does not release steering',!pointers.state.boost&&pointers.state.steer===1);
check('Gauge needles cover correct sweep',gaugeAngle(0,200)===135&&gaugeAngle(100,200)===270&&gaugeAngle(200,200)===405&&gaugeAngle(999,200)===405);
const roads=[{name:'test road',width:20,points:[new T.Vector3(0,.045,1500),new T.Vector3(0,.045,-1500)]}];
const route=prepareTrafficRoutes(roads)[0],a=sampleLane(route,700,1),b=sampleLane(route,700,-1);check('Both traffic directions keep left',a.x<0&&b.x>0&&a.fz<0&&b.fz>0);
const tp=createPhysics();tp.reset(500,0);const traffic=createTraffic(new T.Scene(),tp,{roads});
check('Fixed light pool has cars and buses',traffic.items.length===TRAFFIC_COUNT&&traffic.items.filter(x=>x.bus).length===7&&traffic.items.filter(x=>!x.bus).length===35);
const lead=traffic.items[0],start=lead.distance;for(let i=0;i<600;i++){traffic.update(1/60,tp.chassis);tp.step(1/60,idle);}
check('Traffic advances along roads',Math.abs(lead.distance-start)>10,{metres:Math.abs(lead.distance-start)});
// Isolate a clear lane, and place the stationary player well ahead of its bus.
for(const item of traffic.items){item.distance=2200+item.id*12;item.speed=0;item.pose=sampleLane(route,item.distance,item.direction);}
lead.distance=400;lead.direction=1;lead.speed=7.5;lead.pose=sampleLane(route,400,1);tp.reset(lead.pose.x,lead.pose.z-35,0);
for(let i=0;i<600;i++){traffic.update(1/60,tp.chassis);tp.step(1/60,idle);}
const gap=Math.hypot(lead.pose.x-tp.chassis.position.x,lead.pose.z-tp.chassis.position.z);
check('Bus yields behind stationary player',lead.speed<.2&&gap>8&&gap<20,{gap,speed:lead.speed});
check('Nearby traffic has a matching solid collider',lead.body.world===tp.world&&Math.hypot(lead.body.position.x-lead.pose.x,lead.body.position.z-lead.pose.z)<.1);
traffic.clearAround(tp.chassis.position.x,tp.chassis.position.z,35);check('Recovery clears traffic from spawn',traffic.items.every(item=>Math.hypot(item.pose.x-tp.chassis.position.x,item.pose.z-tp.chassis.position.z)>=35));
const ids=traffic.items.map(x=>x.body.id);for(let i=0;i<7200;i++)traffic.update(1/60,{position:{x:9999,z:9999}});check('Traffic pool remains bounded with distant colliders removed',traffic.items.length===42&&traffic.items.every((v,i)=>v.body.id===ids[i]&&!v.body.world));
console.log(JSON.stringify({tests:results.length,results},null,2));
